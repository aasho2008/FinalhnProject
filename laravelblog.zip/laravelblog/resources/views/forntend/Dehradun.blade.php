@extends('layouts.guest')

@section('content')
<!--Start Navgationbar header-->
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 header">
			<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 padding-left-0 padding-right-0      side-menu"  onclick="openNav()">&#9776; 
			 </div>
			    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-center logo-section ">
			      <a href="hungernight1.html"<img src="images/logo.jpg" style="height: 65%;"></a>
				   <span id="hunger-text">HUNGER NIGHT</span>
			    </div>
			<div class="header-right">
			<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 cart-root">
			
				<button class="cart-button">
					<div class="cart-icon"><i class="fa fa-shopping-cart"></i>
					</div>
						<div class="cart-total">
							<span>0</span>
						</div>
				</button>
				
			</div>
		</div>
	</div>
	<!--End Navgationbar header-->		   
 <!--start leftside navmenu on header-->
    <div id="mySidenav" class="sidenav">
		  <a href="javascript:void(0)" id="closebtn" onclick="closeNav()">&times;</a>
		  <hr>
		  <a href="hungernight1.html"><i class="fa fa-home" aria-hidden="true"></i>Home</a>
		  <a href="#"><i class="fa fa-question-circle"></i>Help</a>
		  <a href="signup.html"><i class="fa fa-user"></i>Signup/Signin</a>
		 <hr>
		  <a href="hungernight1.html">Home</a>
		  <a href="#">Help</a>
		  <a href="aboutus.html">About Us</a>
		  <a href="#career.html">Career</a>
		  <a href="#">Blog</a>
		  <a href="Accessbility.html">Accessbility</a>
		  <a href="#">Be a Hunger Night</a>
		 <button class="button-sidenav">Get Hunger Night Credits</button>
	</div>
	 <!--End leftside navmenu in header-->
	 <!--Start RightsidemyCartnav orderdetails on header-->
	<div id="myCartSideNav" class="cartSideNav" style="border-left: 1px solid #CCCCCC;">
		  <a href="javascript:void(0)" id="closebtnCart" onclick="closeCartNav()" style="">&times;</a>
		  <hr>

	</div>
	<!--End RightsidemyCartnav orderdetails on header-->	
		
	<!--Start main Contents after header-->	
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding">
				<img src="images/anim1.png" height="400px" width="100%">
					<div class="centered">Favourite Food Delivery in Dehradun</div>
					<div class="centered1">Get your favourite Dehradun restaurant delivery food at your door step</div>
					<div class="centered2">Deliverly Address</div>

					<div class="box">
					  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center input-container padding-15">
					      
					      <input class="input" type="search" id="search" placeholder="Enter Your delivery address ">
					      <button class="search-btn" type="">Find Restaurant</button>
					  </div>
				</div>			 
		</div>
		
		
	
		
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="location">
				<a href="#">HungerNight</a> >
				<a href="#">Food Delivery</a> >
				<a href="#">Dehradun</a>
			</div>
		</div>

		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		
			<div class="icon1">
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
			</div>
		</div>
		
		<!--<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 group2">
			<span>Display 20 of 150 deloivery option in Dehradun</span>
		</div>-->
	<div class="main">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin-zero"    style="margin-top: 30px;">
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				<span>
				Note for underground
				sector,Dehradun
				</span>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin-zero">
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				<span>
				Note for underground
				sector,Dehradun
				</span>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin-zero">
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				<span>
				Note for underground
				sector,Dehradun
				</span>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin-zero">
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				<span>
				Note for underground
				sector,Dehradun
				</span>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png" height="100px" width="240px">
				Note for underground
				sector,Dehradun
				</div>
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
		</div>
		<div class="center1">
			<ul class="pagination">
				<li><a href="#"><<</a></li>
				<li><a href="#">1</a></li>
				<li><a href="#">2</a></li>
				<li><a href="#">3</a></li>
				<li><a href="#">4</a></li>
				<li><a href="#">5</a></li>
				<li><a href="#">>></a></li>
			</ul>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
				</div>
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
			Hunger Night is food delivery anywhere you go. With one of the largest networks of restaurant delivery options in San Francisco, choose from 1519 restaurants near you delivered in under an hour! Enjoy the most delicious San Francisco restaurants from the comfort of your home or office. Browse by name, cuisine, or staff picks personalized to your location.
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
				</div>
			</div>

			
		</div>
	</div>
</div>
<!--End main Contents after header-->		
<!--start both leftside navmenu and RightsidemyCartnav on header-->
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "300px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0px";
}
function openCartNav() {
    document.getElementById("myCartSideNav").style.width = "300px";
}

function closeCartNav() {
    document.getElementById("myCartSideNav").style.width = "0px";
}
</script>
<!--End both leftside navmenu and RightsidemyCartnav on header-->
@endsection


@section('pageTitle')
{{ "dehradun" }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')
@endsection
