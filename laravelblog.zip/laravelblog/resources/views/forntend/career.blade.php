@extends('layouts.guest')
@section('content')
	<div class="container">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 header">
			<div class="col-lg-9 col-md-9 col-sm-9 col-xs-9 logo-section">
			
			 
			
			<div class="col-lg-12 col-md-12 col-sm-11 col-xs-11 logo-text   ">
			<a href="hungernight1.html"><img src="images/logo.jpg" style="height: 65%;"></a>
			<span id="hunger-text">HUNGER NIGHT</span>
			</div>
				</div>
			<div class="">
			<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 about-section ">
				<a href="aboutus.html" class="about-page">About Us</a>
			</div>
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 about-section ">
				<a href="career.html" class="about-page">Careers</a>
			</div>
		<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 about-section ">
				<a href="#" class="about-page">Blog</a>
			</div>
			</div>
			</div>
			
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-0 padding">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center career-div">
					<h1>Looking empower</h1>
				</div>
				<img src="images/Career-Hunger-Night.jpg" width="100%" alt="Image" class="career-banner">
			</div>
			<section class="career">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 career-div">
					<h1 >Transforming cities, changing lives</h1>
					<p class="career-paragraph">At HungerNight, we’re working to empower local communities and in turn, creating new ways for people to earn, work, and thrive. We are passionate about building solutions with the power to transform cities — and we’d love for you to join us.</p>
					<a href="#"><div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  see-jobs">
						See Jobs
						 <svg class="sc-kPVwWT guyZzi" height="14" viewBox="0 0 311 66"><g fill="none" transform="translate(1.000000, 1.000000)" stroke="#f79a0ff0" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline><g transform="translate(154.500000, 47.500000) scale(1, -1) translate(-154.500000, -47.500000) translate(0.000000, 31.000000)"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline></g></g></svg>
					</div></a>
				</div>
			</section>
			
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1 class="career-del_good">Delivering good(ness)</h1>
					<p class="career-paragraph">We’re dedicated to making the rest of your life as rewarding&nbsp;as&nbsp;your&nbsp;job.</p>
					
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 goods-services">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center ">
						<img src="HealthWellnesss.jpg" alt="image" height="64px">
						<h2 class="services" size="16" color="#518C8F">Health &amp; Wellness</h2>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<p class="services-paragraph" >Premium medical, dental and&nbsp;vision&nbsp;insurance&nbsp;plans</p>
							<p class="services-paragraph" >$75 monthly fitness reimbursement</p>
						</div>
					</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center ">
						<img src="HealthWellnesss.jpg" alt="image" height="64px">
						<h2 class="services" size="16" color="#518C8F">Time When You Need It </h2>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<p class="services-paragraph" >Unlimited vacation days for salaried employees</p>
							<p class="services-paragraph" >Generous vacation and sick days for hourly team members</p>
						</div>
					</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center ">
						<img src="HealthWellnesss.jpg" alt="image" height="64px">
						<h2 class="services" size="16" color="#518C8F">Compensetion</h2>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<p class="services-paragraph" >Premium medical, dental and&nbsp;vision&nbsp;insurance&nbsp;plans</p>
							<p class="services-paragraph" >Meaningful equity opportunities</p>
						</div>
					</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center ">
						<img src="HealthWellnesss.jpg" alt="image" height="64px">
						<h2 class="services" size="16" color="#518C8F">Perks</h2>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<p class="services-paragraph" >Quarterly off-sites and team-building activities</p>
							<p class="services-paragraph" >Fully-stocked kitchen</p>
						</div>
					</div>
					
			</div>

			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  career">
				<h1 class="career-del_good">Find your dream team</h1>
				<p class="career-paragraph">Our headquarters are located in 4-B D1 Arawali Apartment, 
              Sector 52 Noida, Noida, 
              Uttar Pradesh 201301, . We’re also hiring for many different positions across Noida.</p>
			</div>
			
				<div class=" text-center accessibility-content">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 accessibility-heading"><h1>Accessibility</h1>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 accessibility-paragraph"><p >HungerNight is committed to connecting people with possibility. As part of that commitment, we seek to ensure that work opportunities at HungerNight are accessible to all.</p>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 accessibility-paragraph"><p >If you have a disability under the Indian with Disabilities Act or a similar law and you wish to discuss potential accommodations related to applying for employment at our company, please contact info@hungernight.com.</p>
				</div>
				</div>
			
		</div>	
@endsection
@section('pageTitle')
{{ "career" }}
@endsection

@section('addtional_css')

@endsection

@section('jscript')

@endsection
