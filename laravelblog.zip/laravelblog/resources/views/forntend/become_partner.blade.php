
@extends('layouts.guest')

@section('content')

		 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 Hunger-applyPage">
       <section class="Hunger-root ">
	   
       <div class="carousel slide carousel-fade" data-ride="carousel">

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
	 <div class="item active">
		<div class="Partner_LeftText-portion">
			<h1 class="Partner_LeftText-head">"It really adds to the bottom line”</h1>
			<h2 class="Partner_LeftText-subhead"> — Chuck Hammers, Pizza My Heart</h2>
		</div>
        </div>
        <div class="item ">
		        <div class="Partner_LeftText-portion ">
			<h1 class="Partner_LeftText-head ">"More business out the door than inside”</h1>
			<h2 class="Partner_LeftText-subhead"> — Amir Hosseini, Curry Up Now</h2>
		</div>
        </div>
       
       
    </div>
</div>
		
			
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  HungerRightText_Signup">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 Signup_contained">
                    <h1 class="col-lg-12 col-md-12 col-sm-12 col-xs-12 SignupForm_formTitle">Activate Hunger Night in days
				</h1>
                    <p class="SignupForm_formSubtitle"></p>
                    <form action="" method="post" class="SignupForm_formContent">
                        <div class="Input_Email">
                            <div class="Input_labels">
                                <label class="input_primary"></label>
                            </div>
                            <div class="Input_container">
                                <input type="text" placeholder="Store name" class="Inputs_fields" autocomplete="store name" value="" name="Store_name">
                            </div>
                        </div>
                        <div class="Input_Email">
                            <div class="Input_labels">
                                <label class="input_primary"></label>
                            </div>
                            <div class="Input_container">
                                <input type="text" placeholder="Store address" class="Inputs_fields" autocomplete="Store address" value="" name="Store_address">
                            </div>
                        </div>
                        <div class="SignupForm_splitSection">
                            <div class="input-root input-half">
                                <div class="Input_labels">
                                    <label class="Input_primary"></label>
                                </div>
                                <div>
                                    <div>
                                        <input type="text" placeholder="Full name" autocomplete="Full name" value="" name="full_name" class="Input_Container">
                                    </div>
                                    <div class="Input_zipAddress">
                                    </div>
                                </div>

                            </div>

                            <div class="input-root input-half">
                                <div class="Input_labels">
                                    <label class="Input_primary"></label>
                                </div>
                                <div class="Input_Container">
                                    <input type="tel" placeholder="Phone Number" class="Inputs_fields" value="" name="phoneNumber" maxlength="16">
                                </div>
                            </div>

                        </div>
                        <div class="Input_Email">
                            <div class="Input_labels">
                                <label class="input_primary"></label>
                            </div>
                            <div class="Input_container">
                                <input type="email" placeholder="Email" class="Inputs_fields" autocomplete="Email" value="" name="email">
                            </div>
                        </div>

                        <button class="login-submit submit-text" tabindex="4" type="submit">Get started</button>

                    </form>
                </div>
            </div>

        </section>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 Partner_middleSection">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 Partner_middletop">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 Partner_LeftText">
                <ul class="Partner_LeftText-UList">
                    <li class="Partner_LeftText-List">
                        <h1 class="Partner_LeftText-Heading">Get more customers with less staff</h1>
                        <p class="Partner_LeftText-Paragraph">Our app and site will put your menu in front of the whole town.</p>
                    </li>
                    <li class="Partner_LeftText-List">
                        <h1 class="Partner_LeftText-Heading">We’ll work with what you have</h1>
                        <p class="Partner_LeftText-Paragraph">DoorDash can send you orders over fax, computer, or tablet.</p>
                    </li>
                    <li class="Partner_LeftText-List">
                        <h1 class="Partner_LeftText-Heading">Get back to what you care about</h1>
                        <p class="Partner_LeftText-Paragraph">We will take care of the customer and logistics before, during, and after the delivery.</p>
                    </li>
                </ul>
            </div>
            <div class="Partner_RightImage">
                <div class="TransparentImage">
                    <img src="images/gear-image.jpg">
                </div>
            </div>

        </div>

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="Partner_requestSection">
                <div>
                    <h1 class="Partner_requestSection_Title">Or, request a Dasher to help.</h1>
                    <p class="Partner_requestSection_Paragraph">Phone orders, small requests, big events, special deliveries, and anything else. Hunger Night Drive enables restaurants to offer delivery for orders you receive from your customers directly.</p>
                </div>
                <a href="" class="Partner_requestSectionButton">Learn more</a>
            </div>
        </div>
    </div>
    <div class="Restaurants_Partner">
        <h1 class="Restaurants_PartnerTitle">Restaurants love us</h1>
        <p class="Restaurants_PartnerParagraph">We’ve powered millions of deliveries in more than 850 cities, partnering with thousands of local merchants to build their business.</p>
    </div>

    <div class="signup_NighterSection">
        <div class="signup_NighterChecklist">
            <ol class="Signup_NighterList">
                <li class="signup_NighterListitem">
                    <h1 class="signup_NighterListitem_Title">1. Signup Online</h1>
                    <p class="signup_NighterListitem_Description">Submit a form with your store and contact information.</p>
                   
                </li>
                <li class="signup_NighterListitem padding-10">
                    <h1 class="signup_NighterListitem_Title">2. We’ll contact you</h1>
                    <p class="signup_NighterListitem_Description">Our sales team will get back to you quickly, and we’ll collect any more info we need to get you listed.</p>

                </li>
                <li class="signup_NighterListitem">
                    <h1 class="signup_NighterListitem_Title">3. Start getting orders this week</h1>
                    <p class="signup_NighterListitem_Description">Once you’re listed, you’ll start receiving orders from customers on DoorDash.</p>
                  
                </li>
            </ol>
        </div>
        <div class="SignupForm_Bottom">
            <div class="">
                <h1 class="SignupForm_formTitle">Start delivering this week</h1>
                <p class="SignupForm_formSubti"></p>
                 <form action="" method="post" class="SignupForm_formContent">
                        <div class="Input_Email">
                            <div class="Input_labels">
                                <label class="input_primary"></label>
                            </div>
                            <div class="Input_container">
                                <input type="text" placeholder="Store name" class="Inputs_fields" autocomplete="store name" value="" name="Store_name">
                            </div>
                        </div>
                        <div class="Input_Email">
                            <div class="Input_labels">
                                <label class="input_primary"></label>
                            </div>
                            <div class="Input_container">
                                <input type="text" placeholder="Store address" class="Inputs_fields" autocomplete="Store address" value="" name="Store_address">
                            </div>
                        </div>
                        <div class="SignupForm_splitSection">
                            <div class="input-root input-half">
                                <div class="Input_labels">
                                    <label class="Input_primary"></label>
                                </div>
                                <div>
                                    <div>
                                        <input type="text" placeholder="Full name" autocomplete="Full name" value="" name="full_name" class="Input_Container">
                                    </div>
                                    <div class="Input_zipAddress">
                                    </div>
                                </div>

                            </div>

                            <div class="input-root input-half">
                                <div class="Input_labels">
                                    <label class="Input_primary"></label>
                                </div>
                                <div class="Input_Container">
                                    <input type="tel" placeholder="Phone Number" class="Inputs_fields" value="" name="phoneNumber" maxlength="16">
                                </div>
                            </div>

                        </div>
                        <div class="Input_Email">
                            <div class="Input_labels">
                                <label class="input_primary"></label>
                            </div>
                            <div class="Input_container">
                                <input type="email" placeholder="Email" class="Inputs_fields" autocomplete="Email" value="" name="email">
                            </div>
                        </div>

                        <button class="login-submit submit-text" tabindex="4" type="submit">Get started</button>

                    </form>
            </div>
        </div>
    </div>
		
@endsection


@section('pageTitle')
{{ "login" }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')
@endsection