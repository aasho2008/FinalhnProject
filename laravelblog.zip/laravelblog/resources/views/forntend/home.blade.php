@extends('layouts')

@section('content')
<!--Start Navgationbar header-->
        <div class="container">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 header">
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 logo-section">
                    <div class="col-lg-12 col-md-12 col-sm-11 col-xs-11 logo-text text-center ">
                        <a href="hungernight1.html"><img src="images/logo.jpg" style="height: 65%;"></a>
                        <span id="hunger-text">HUNGER NIGHT</span>
                    </div>
                </div>          
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 signup-section text-right">
                    <a href="login.html" class="btn">Sign In</a>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 signup-section text-right">
                    <a href="signup.html"><button class="button">Sign Up</button></a>
                </div>      
            </div>
            <!--End Navgationbar header-->   
            <!--Start main Contents after header-->       
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="box_delivery">
                          <div class="serachBarheadertext">Delivering Good Day Time</div> 
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 input-container padding-15">                        
                          <input class="input" type="search" id="search" placeholder="Enter Your delivery address">
                          <button class="search-btn" type="">Find Restaurant</button>
                      </div>
                    </div>
                    <div>Get The App <i class="fab fa-apple" aria-hidden="true"></i><i class="fa fa-android" aria-hidden="true"></i>
                    </div>
                    <div id="myCarousel" class="col-lg-12 col-md-12 col-sm-12 col-xs-12 carousel slide" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                      <li data-target="#myCarousel" data-slide-to="1"></li>
                      <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">
                      <div class="item active">
                        <img src="images/bnr1.jpg" alt="food" style="width:100%;">
                      </div>

                      <div class="item">
                        <img src="images/food_ordering_banner.jpg" alt="food" style="width:100%;">
                      </div>

                      <div class="item">
                        <img src="images/bnr10.jpg" alt="food" style="width:100%;">
                      </div>
                    </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 Del-portion size="64">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 del-width" >
                            <h1 class="del-door">Delivering Goods: Delivering At Your Doorstep</h1>
                        </div>
                        <a href="aboutus.html">
                        <div class="arrow-portion">
                            <svg class="" height="32" viewBox="0 0 311 66"><g fill="none" transform="translate(1.000000, 1.000000)" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline><g transform="translate(154.500000, 47.500000) scale(1, -1) translate(-154.500000, -47.500000) translate(0.000000, 31.000000)"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline></g></g></svg>
                        </div>
                        </a>
                    </div>
                    <!--Session Start text and image-->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 animationBlock">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 mobile-portion textLeft">
                            <div class="centertextLeft"><b>Satisfy your cravings</b><br/>
                            <br/><p>Experience a world of food, with your favorite restaurants at your fingertips.</p></div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 mobile-portion imgRight" id="imgslide"></div>
                    </div>
                    <!--Session End text and image-->
                    <!--Session Start text and image-->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 animationBlock">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 mobile-portion imgLeft" id="imgslide1"></div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 mobile-portion textLeft">
                            <div class="centertextLeft"><b>Anywhere you are</b><br/>
                            <br/><p>A family picnic in the park. Your date night at home. That late-night study session. Spend more time doing the things that matter to you most — we’ll take care of the rest.</p></div></div>
                        </div>
                    </div>
                    <!--Session End text and image-->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mobile-portion">
                        <h1>How it works</h1>
                        <div class="img"><img src="images/mobile.jpg"></div>
                        <h1>FIND YOUR FAVOURITS</h1>
                        <p class="">Satisfy your cravings with a huge selection</p>
                        <p class="">of resturants.</p>              
                    </div>
                    <!-- start order seach box -->
                    <div class="order">
                        <h1 class="">Ready to order?</h1>
                        <div class="box">
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 input-container padding-15">
                                  <input class="input" type="search" id="search" placeholder="Enter Your delivery address ">
                                  <button class="search-btn" type="">Find Restaurant</button>
                              </div>
                        </div>
                   <!-- End order seach box -->
                        <!-- start Get the app icon -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-15">
                            <h3 class="app-heading">Get the app:</h3>
                            
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 apps-social">
                            <a class="get-apps" href="#"><i class="fa fa-apple" aria-hidden="true"></i></a>
                            <a class="get-apps" href="#"><i class="fa fa-android" aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <!-- End Get the app icon -->
                    </div>
                </div>
            </div>
        </div>
    

@endsection
@section('pageTitle')
{{ "home" }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')
@endsection