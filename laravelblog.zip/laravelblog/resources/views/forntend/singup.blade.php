
@extends('layouts.guest')

@section('content')

		<div class="login-root">
			<div class="login-centered">
				<span class="opacityAndSize_parent text-center">
					<div>
					`	<h1 class="login-h1">Sign Up</h1>
						<p class="login-p">Already have an account?
						<a href="login.html">	<button class="signup-link">Sign in</button></a>
						</p>
						<center>
						<div class="width">
						<button class="signin-facebook">
							<span class="login-btnIconcontroller">
								<i class="fa fa-facebook"></i>
								Sign in with Facebook
							</span>
						</button>
						<button class="signin-google">
							<span class="login-btnIconcontroller">
								<i class="fa fa-google"></i>
								Sign in with Google
							</span>
						</button>
						<p class="login-orWithEmail">
						
						Or continue with email
						
						</p>
						<form id="signup_form text-center"  method="post" action="" >
						    <label class="input-root input-half">
								<div class="input-label">First name</div>
								<input type="text" id="f_name" class="input-input" tabindex="1" value name="f_name">
							</label>
							<label class="input-root input-half">
								<div class="input-label">Last name</div>
								<input type="text" id="l_name" class="input-input" tabindex="2" value name="l_name">
							</label>
							<label class="input-root">
								<div class="input-label">Email</div>
								<input type="email" id="email" class="input-input" tabindex="3" value name="email">
							</label>
							<label class="input-root">
								<div class="input-label">Mobile number</div>
								<input type="text" id="mobile_number" class="input-input" tabindex="3" value name="mobile-number">
							</label>
							<label class="input-root">
								<div class="input-label">Password</div>
								<div class="input-subLebel-signup">at least 8 characters</div>
								<div class="input-password">
									<input type="password" id="password" class="input-input" tabindex="5" value name="password">
									<div class="input-show" tabindex="-1">Show</div>
								</div>
							</label>
							<p class="login-terms">By clicking Sign up, Continue with Facebook, or Continue with Google, you agree to our
							<a class="login-termslink" href="#" target="_blank">Terms and Conditions</a> and
							<a class="login-termslink" href="#" target="_blank">Privacy Statement</a>
							</p>
							<button class="login-submit submit-text" tabindex="4" type="submit">Sign up
							</button>
							
						</form>
						</div>
						</center>
					</div>
				</span>
				
			</div>
		</div>
		
@endsection


@section('pageTitle')
{{ "login" }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')
@endsection