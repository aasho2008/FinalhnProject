
@extends('layouts.guest')

@section('content')

		
		
	</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 Hunger-applyPage">
			<section class="Hunger-root">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 HungerLeft_text">
					<h1 class="HungerLeft_heading">
						Bring home the becon.
					</h1>
					<h2 class="HungerLeft_Subheading">
						Start delivering today and make great money on your own schedule.
					</h2>
				</div>
				<div class="Hunger_videoContainer">
					<video autoplay="" loop="" class="Hunger_video" __idm_id__="394450945">
					<source src="" type="video/mp4"></video>
				</div>
					
				
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  HungerRightText_Signup">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 Signup_contained">
				<h1 class="col-lg-12 col-md-12 col-sm-12 col-xs-12 SignupForm_formTitle">Get your first check this week
				</h1>
				<p class="SignupForm_formSubtitle"></p>
				<form action="" method="post" class="SignupForm_formContent">
				<div class="Input_Email">
				<div class="Input_labels">
				<label class="input_primary"></label>
				</div>
				<div class="Input_container">
				<input type="email" placeholder="Email" class="Inputs_fields" autocomplete="email" value="" name="email">
				</div>
				</div>
				<div class="SignupForm_splitSection">
				<div class="input-root input-half">
				<div class="Input_labels">
				<label class="Input_primary"></label>
				</div>
				<div class="Input_Container">
				<input type="tel" placeholder="Phone Number" class="Inputs_fields" value="" name="phoneNumber" maxlength="16"></div></div>
				<div class="input-root input-half">
				<div class="Input_labels">
				<label class="Input_primary"></label>
				</div><div><div>
				<input type="zip" placeholder="Your ZIP / Postal Code" autocomplete="shipping postal-code" value="" name="zipCode" class="Input_Container">
				</div>
				<div class="Input_zipAddress"></div></div></div></div>
				<p class="SignupForm_Disclaimer">
				<label>
				<input type="checkbox" class="SignupForm_checkbox" value="" name="hasCheckedAgreement">I consent to receive emails, calls, or SMS messages including by automatic telephone dialing system from DoorDash to my email or phone number(s) above for informational and/or marketing purposes. Consent to receive messages is not a condition to make a purchase or sign up. I agree to the<a class="SignupForm_link" href="" target="_blank">Independent Contractor Agreement</a>and have read the<a class="SignupForm_link" href="" target="_blank">Dasher Privacy Policy</a></label></p>
				<a href="signup.html"><button class="login-submit submit-text" tabindex="4" type="submit">Sign up</button></a>
				<button type="button" class="SignupForm_alreadyStartedLink">Already started signing up?</button>
				</form>
				</div>
				</div>
			</section>
			<section class="Testimonial_section">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 love_hungering">
					<h1>"Why I love Hungring..."</h1>	
			</div>
			
			<p class="Testimonial_paragraph">People Dash for a variety of reasons: to spend time with their kids, earn extra money, to pay for school, even to exercise and see the world.</p>
			
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-60">
		     <div id="text-carousel" class="carousel slide" data-ride="carousel"> 
			 <ol class="carousel-indicators">
			  <li data-target="#text-carousel" data-slide-to="0" class="active"></li>
			  <li data-target="#text-carousel" data-slide-to="1"></li>
			  <li data-target="#text-carousel" data-slide-to="2"></li>
			</ol>
				<div class="carousel-inner">
					<div class="item active">
						<div class="carousel-content">
							<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-30 review-index">
									
									<div>
										<p>Hunger Night provides best services</p>
										<p>Gudgaon One Apartments, Gudgaon</p>
										<p><strong>Faisal</strong></p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-30 review-index">
									
									<div>
										<p>Huner night Provides best services</p>
										<p>(Sukh Shanti Apartments, Gudgaon)</p>
										<p><strong>Faisal</strong></p>
									</div>	
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-30 review-index">
									
									<div>
										<p>Hunger Night provides best services</p>
										<p>(Sukh Shanti Apartments, Gudgaon)</p>
										<p><strong>Faisal</strong></p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="carousel-content">
							<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-30 review-index">
									
									<div>
										<p>Hunger Night provides best services</p>
										<p>Gudgaon One Apartments, Gudgaon</p>
										<p><strong>Faisal</strong></p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-30 review-index">
									
									<div>
										<p>Hunger Night provides best services</p>
										<p>(Sukh Shanti Apartments, Gudgaon)</p>
										<p><strong>Faisal</strong></p>
									</div>	
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-30 review-index">
									
									<div>
										<p>Hunger Night provides best services</p>
										<p>(Sukh Shanti Apartments, Gudgaon)</p>
										<p><strong>Faisal</strong></p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="carousel-content">
							<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-30 review-index">
									
									<div>
										<p>Hunger Night provides best services</p>
										<p>Gudgaon One Apartments, Gudgaon</p>
										<p><strong>Faisal</strong></p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-30 review-index">
									
									<div>
										<p>Hunger Night provides best services</p>
										<p>(Sukh Shanti Apartments, Gudgaon)</p>
										<p><strong>Faisal</strong></p>
									</div>	
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-30 review-index">
									
									<div>
										<p>Hunger Night provides best services</p>
										<p>(Sukh Shanti Apartments, Gudgaon)</p>
										<p><strong>Faisal</strong></p>
									</div>
								</div>
							</div>
						</div>
					</div>
					
				</div>
				<a class="left carousel-control review-left" href="#text-carousel" data-slide="prev">
					<span class="glyphicon glyphicon-menu-left"></span>
					 <span class="sr-only">Previous</span>
				  </a>
				 <a class="right carousel-control review-right" href="#text-carousel" data-slide="next">
					<span class="glyphicon glyphicon-menu-right"></span>
					 <span class="sr-only">Next</span>
				  </a>
		</div>
			
		</div>
			</section><br>
			<section class="signup_NighterSection">
				<div class="signup_NighterChecklist">
					<ol class="Signup_NighterList">
						<li class="signup_NighterListitem">
							<h1 class="signup_NighterListitem_Title">1. Get activated</h1>
							<p class="signup_NighterListitem_Description">Give us your info and we’ll do a background check to get you on your way.</p>
							<button class="signup_NighterListitem_Link">See full requirements.</button>
						</li>
						<li class="signup_NighterListitem padding-10">
							<h1 class="signup_NighterListitem_Title">2. Get ready</h1>
							<p class="signup_NighterListitem_Description">Pick up the basics of Dashing, some gear, and the iOS or Android app.</p>
							
						</li>
						<li class="signup_NighterListitem">
							<h1 class="signup_NighterListitem_Title">3. Get paid</h1>
							<p class="signup_NighterListitem_Description">Turn on the app, accept some orders, and start bringing home the bacon.</p>
							<button class="signup_NighterListitem_Link">See full FAQ.</button>
						</li>
					</ol>
				</div>
				<div class="SignupForm_Bottom">
					<div class="">
						<h1 class="SignupForm_formTitle">Get ready to deliver</h1>
						<p class="SignupForm_formSubti"></p>
						<form action="" method="post" class="SignupForm_formContent">
				<div class="Input_Email">
				<div class="Input_labels">
				<label class="input_primary"></label>
				</div>
				<div class="Input_container">
				<input type="email" placeholder="Email" class="Inputs_fields" autocomplete="email" value="" name="email">
				</div>
				</div>
				<div class="SignupForm_splitSection">
				<div class="input-root input-half">
				<div class="Input_labels">
				<label class="Input_primary"></label>
				</div>
				<div class="Input_Container">
				<input type="tel" placeholder="Phone Number" class="Inputs_fields" value="" name="phoneNumber" maxlength="16"></div></div>
				<div class="input-root input-half">
				<div class="Input_labels">
				<label class="Input_primary"></label>
				</div><div><div>
				<input type="zip" placeholder="Your ZIP / Postal Code" autocomplete="shipping postal-code" value="" name="zipCode" class="Input_Container">
				</div>
				<div class="Input_zipAddress"></div></div></div></div>
				<p class="SignupForm_DownDisclaimer">
				<label>
				<input type="checkbox" class="SignupForm_checkbox" value="" name="hasCheckedAgreement">I consent to receive emails, calls, or SMS messages including by automatic telephone dialing system from DoorDash to my email or phone number(s) above for informational and/or marketing purposes. Consent to receive messages is not a condition to make a purchase or sign up. I agree to the<a class="SignupForm_link" href="" target="_blank">Independent Contractor Agreement</a>and have read the<a class="SignupForm_link" href="" target="_blank">Dasher Privacy Policy</a></label></p>
				<a href="signup.html"><button class="login-submit submit-text" tabindex="4" type="submit">Sign up</button></a>
				<button type="button" class="SignupForm_alreadyStartedLink">Already started signing up?</button>
				</form>
						</div>
				</div>
			</section>
		
	
</div>
		
@endsection


@section('pageTitle')
{{ "login" }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')
@endsection