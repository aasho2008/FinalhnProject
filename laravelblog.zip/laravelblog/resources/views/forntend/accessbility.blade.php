
@extends('layouts.guest')

@section('content')

		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center accessibility-image">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
					<svg>
					 <img src="images/header-image.svg"  >
					</svg>
					</div>
			</div>
			
				<div class=" text-center accessibility-content">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 accessibility-heading"><h1>Accessibility</h1>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 accessibility-paragraph"><p >HungerNight is committed to connecting people with possibility. As part of that commitment, we seek to ensure that work opportunities at HungerNight are accessible to all.</p>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 accessibility-paragraph"><p >If you are vision-impaired or have another impairment covered by the Indian with Disabilities Act or a similar law, and you wish to discuss potential accommodations related to using the HungerNight platform, please contact <a href="#">+91- 9958033045</a></p>
				</div>
				</div>
		</div>
		
@endsection


@section('pageTitle')
{{ "accessbility" }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')
@endsection