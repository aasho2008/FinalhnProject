@extends('layouts.app')
@section('content')


<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-0">
                <video width="100%" controls>
                  <source src="mov_bbb.mp4" type="video/mp4">
                  <source src="mov_bbb.ogg" type="video/ogg">
                  Your browser does not support  video.
                </video>
            </div>
            <section class="about">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 about-div">
                    <h1 >Who we are</h1>
                    <p class="about-paragraph">HungerNight is a technology company that connects people with the best in their cities. We do this by empowering local businesses and in turn, generate new ways for people to earn, work and live. We started by facilitating door-to-door delivery, but we see this as just the beginning of connecting people with possibility — easier evenings, happier days, bigger savings accounts, wider nets&nbsp;and&nbsp;stronger&nbsp;communities.</p>
                </div>
            </section>
            
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h1 class="about-del_good">Delivering good to…</h1>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  del-portion_right" >
                        <h1 class="customer">Customers</h1>
                    <p class="about-paragraph">With your favorite restaurants at your fingertips, DoorDash satisfies your cravings and connects you with possibilities — more time and energy for yourself and those you love.</p>
                    <a href="#" class="order-link">
                    <div class="start-order">
                       <div class="">Start an order
                        <svg class="sc-kPVwWT guyZzi" height="14" viewBox="0 0 311 66"><g fill="none" transform="translate(1.000000, 1.000000)" stroke="#77B7C4" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline><g transform="translate(154.500000, 47.500000) scale(1, -1) translate(-154.500000, -47.500000) translate(0.000000, 31.000000)"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline></g></g></svg>
                
                    </div>
                    </div>
                    </a>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  del-portion_right" >
                        <h1 class="customer">Dashers</h1>
                    <p class="about-paragraph">Delivering with DoorDash, you get flexibility and financial stability. Dash for a living or for a goal, all on your schedule and on your own terms.</p>
                    <a href="#" class="order-link">
                    <div class="start-order">
                       <div class="">Dash Now
                        <svg class="sc-kPVwWT guyZzi" height="14" viewBox="0 0 311 66"><g fill="none" transform="translate(1.000000, 1.000000)" stroke="#77B7C4" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline><g transform="translate(154.500000, 47.500000) scale(1, -1) translate(-154.500000, -47.500000) translate(0.000000, 31.000000)"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline></g></g></svg>
                
                    </div>
                    </div>
                    </a>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  del-portion_right" >
                        <h1 class="customer">Merchants</h1>
                    <p class="about-paragraph">DoorDash’s innovative merchant-focused solutions enhance your success by transforming your business. Open your doors to an entire city and see your reach and revenue grow.</p>
                    <a href="#" class="order-link">
                    <div class="start-order">
                       <div class="">Sign Up now
                        <svg class="sc-kPVwWT guyZzi" height="14" viewBox="0 0 311 66"><g fill="none" transform="translate(1.000000, 1.000000)" stroke="#77B7C4" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline><g transform="translate(154.500000, 47.500000) scale(1, -1) translate(-154.500000, -47.500000) translate(0.000000, 31.000000)"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline></g></g></svg>
                
                    </div>
                    </div>
                    </a>
            </div>
            
        </div>

            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 project-dash size="64">
                <a href="#"><div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 del-width" >
                    <h1 class="project-text">Project Dash</h1>
                </div></a>
                <a href="#">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 del-width" >
                    <p class="project-paratext">$165 billion worth of food is wasted every year. 16 million U.S. households go hungry. See how we’re using our platform to help tackle this problem.</p>
                    </div>
                </a>
                <div class="arrow-portion">
                    <svg class="" height="32" viewBox="0 0 311 66"><g fill="none" transform="translate(1.000000, 1.000000)" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline><g transform="translate(154.500000, 47.500000) scale(1, -1) translate(-154.500000, -47.500000) translate(0.000000, 31.000000)"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline></g></g></svg>
                </div>
            </div>
            <section class="about">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 about-div">
                    <h1 >Our Investors</h1>
                    <div class="our-investors">
                        <li class="investors">
                            <img src="" class="investor-image" alt="investor1">
                        </li>
                        <li class="investors">
                            <img src="" class="investor-image" alt="investor2">
                        </li>
                        <li class="investors">
                            <img src="" class="investor-image" alt="investor3">
                        </li>
                        <li class="investors">
                            <img src="" class="investor-image" alt="investor4">
                        </li>
                        <li class="investors">
                            <img src="" class="investor-image" alt="investor5">
                        </li>
                        <li class="investors">
                            <img src="" class="investors-image" alt="investor6">
                        </li>
                        
                    </div>
                </div>
            </section>
            
            <section class="about">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 about-div">
                    <h1 >Media inquiries</h1>
                    <p class="media-paragraph">For the latest news, please contact
                    <a href="#" class="hunger-email">hungernight@gmail.com</a>.
                    </p>
                    <p class="media-paragraph">Need Dasher assistance?
                    <a href="#" class="hunger-email">Get help here</a>.
                    </p>
                </div>
            </section>
        </div>  


@endsection
@section('pageTitle')
{{ "about_us" }}
@endsection

@section('addtional_css')

@endsection

@section('jscript')

@endsection