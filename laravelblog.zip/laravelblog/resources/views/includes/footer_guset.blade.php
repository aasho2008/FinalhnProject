<footer class="container-fluid text-center footer">
        <div class="row content">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 ">
                    <ul>
                        <li class="liHeading">North India</li>
                        <li><a href="noida_city.html">Noida</a></li>
                        <li><a href="Gaziabad.html">Gaziabad</a></li>
                        <li><a href="Greater Noida.html">Greater Noida</a></li>
                        <li><a href="New Delhi.html">New Delhi</a></li>
                        <li><a href="South Delhi.html">South Delhi</a></li>
                        <li><a href="Gurugram.html">Gurugram</a></li>
                        
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                    <ul>
                        <li class="liHeading">North India</li>
                        <li><a href="Deoria.html">Deoria</a></li>
                        <li><a href="Lucknow.html">Lucknow</a></li>
                        <li><a href="Kanpur.html">Kanpur</a></li>
                        <li><a href="Meerut.html">Meerut</a></li>
                        <li><a href="Dehradun.html">Dehradun</a></li>
                        
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                    <ul>
                        <li class="liHeading">South India</li>
                        <li><a href="#">Banglore</a></li>
                        <li><a href="#">Hydrabad</a></li>
                        <li><a href="#">Tiruvanantpuram</a></li>
                        <li><a href="#">Pune</a></li>
                        <li><a href="#">Chennai</a></li>
                    </ul>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                    <ul>
                        <li class="liHeading">East India</li>
                        
                        <li><a href="#">Ahemdabad</a></li>
                        <li><a href="#">Surat</a></li>
                        <li><a href="#">Barodra</a></li>
                        <li><a href="#">Kota</a></li>
                        <li><a href="#">Jaipur</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                    <ul>
                        <li class="liHeading">Other Cities in India</li>
                        
                        <!--li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li-->
                    </ul>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-0 padding-top-15" >
                    <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                        <ul>
                            <li class="liHeading">GET TO KNOW</li>
                            <li><a href="#">About us</a></li>
                            <li><a href="#">Careers</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Accessibility</a></li>
                            <li><a href="https://www.youtube.com/c/hungernight" onclick="window.open(this.href); return false;" onkeypress="window.open(this.href); return false;">Youtube</a></li>
                            <li><a href="https://twitter.com/hunger_night" onclick="window.open(this.href); return false;" onkeypress="window.open(this.href); return false;">Twitter</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                        <ul>
                            <li class="liHeading">HUNGER NIGHT HELP YOU</li>
                            <li><a href="#">Help us</a></li>
                            <!-- <li><a href="#">demo</a></li>
                            <li><a href="#">demo</a></li>
                            <li><a href="#">demo</a></li>
                            <li><a href="#">demo</a></li>
                            <li><a href="#">demo</a></li> -->
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                        <ul>
                            <li class="liHeading">DOING BUSINESS</li>
                            <li><a href="#">Become a nighter</a></li>
                            <li><a href="#">Be a Partner Restaurant</a></li>
                            <li><a href="#">Get Hunger nighters for  Deliveries</a></li>
                            
                        </ul>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 apps">
                        <a href="#" ><img src="images/app.png" class="mobile-apps" width="148px;"></a>
                        <a href="#"><img src="images/ggogle.png" class="mobile-apps"></a>
                    </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 link" >
                            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                                <a href="#">Terms of Service</a>
                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                                <a href="#">Privacy</a>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                                <a href="#">Delivery Locations</a>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 copyright">
                                © 2018 HungerNight
                            </div>
                            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 social"  id="social-social">
                                <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                </div>
                                <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                </div>
                                <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                </div>  
            </div>
        </div>      
    </footer>