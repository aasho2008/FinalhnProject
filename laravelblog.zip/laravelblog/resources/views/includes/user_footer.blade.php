<footer class="container-fluid text-center footer-login ">
  <div class="row content">
	<div class="col-md-12" >
		<div class="col-md-12" >
			<div class="col-md-2 ">
				<ul>
					<li class="liHeading-login">Get to Know Us</li>
					<li><a href="#">About us</a></li>
					<li><a href="#">Careers</a></li>
					<li><a href="#">Blog</a></li>
					<li><a href="#">Accessibility</a></li>
					<li><a href="https://www.youtube.com/c/hungernight" onclick="window.open(this.href); return false;" onkeypress="window.open(this.href); return false;">Youtube</a></li>
					<li><a href="https://twitter.com/hunger_night" onclick="window.open(this.href); return false;" onkeypress="window.open(this.href); return false;">Twitter</a></li>
				</ul>
			</div>
			<div class="col-sm-2">
				<ul>
					<li class="liHeading-login">Let Us Help You</li>
					<li><a href="#">Account Details </a></li>
					<li><a href="#">Order History</a></li>
					<li><a href="#">Help us</a></li>
				</ul>
			</div>
			<div class="col-sm-4">
				<ul>
					<li class="liHeading-login">Doing Business</li>
					<li><a href="#">Become a nighter</a></li>
					<li><a href="#">Be a Partner Restaurant</a></li>
					<li><a href="#">Get Hunger nighters for  Deliveries</a></li>
				</ul>
			</div>
			<div class="col-sm-2 apps">
				<a href="#"><img src="images/app.png" class="mobile-apps" width="148px;"></a>
				
			</div>
			<div class="col-sm-2 apps">
				<a href="#"><img src="images/ggogle.png" class="mobile-apps"></a>
				
			</div>
			
			
			<div class="col-md-12 padding-0 padding-top-15" >
			
			
			
			<div class="col-md-12 link-footerlogin" >
			
				<div class="col-md-2">
					<a href="#">Terms of Service</a>
				</div>
				<div class="col-md-1">
					<a href="#">Privacy</a>
				</div>
				<div class="col-md-2">
					<a href="#">Delivery Locations</a>
				</div>
				<div class="col-md-2 copyright-login">
					© 2018 HungerNight
				</div>
				
				
				<div class="col-md-5 col-sm-12 col-sm-12 social "  >
					<div class="col-md-1 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-facebook"></i></a>
					</div>
					<div class="col-md-1 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-twitter"></i></a>
					</div>
					<div class="col-md-1 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-instagram"></i></a>
					</div>
				</div>
				
			</div>
		</div>
		
	</div>
	
		
	</div>



</footer>		