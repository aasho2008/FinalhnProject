<div id="mySidenav" class="sidenav">
          <a href="javascript:void(0)" id="closebtn" onclick="closeNav()">&times;</a>
          <hr>
          <a href="hungernight1.html"><i class="fa fa-home" aria-hidden="true"></i>Home</a>
          <a href="#"><i class="fa fa-question-circle"></i>Help</a>
          <a href="signup.html"><i class="fa fa-user"></i>Signup/Signin</a>
         <hr>
          <a href="hungernight1.html">Home</a>
          <a href="#">Help</a>
          <a href="aboutus.html">About Us</a>
          <a href="#career.html">Career</a>
          <a href="#">Blog</a>
          <a href="Accessbility.html">Accessbility</a>
          <a href="#">Be a Hunger Night</a>
         <button class="button-sidenav">Get Hunger night Credits</button>
    </div>


    <div id="myCartSideNav" class="cartSideNav" style="border-left: 1px solid #CCCCCC;">
          <a href="javascript:void(0)" id="closebtnCart" onclick="closeCartNav()" style="">&times;</a>
          <hr>

    </div>
                    
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 header">
            
                
            
            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 padding-left-0 padding-right-0 side-menu"  onclick="openNav()">&#9776; </div>
            <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-center logo-section ">
             <img src="images/logo.jpg" style="height: 65%;">
                <span id="hunger-text">HUNGER NIGHT</span>
            </div>
            <div class="header-right">
            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 cart-root">
            
                <button class="cart-button" onclick="openCartNav()">
                    <div class="cart-icon"><i class="fa fa-shopping-cart"></i></div>
                    <div class="cart-total">
                        <span>0</span>
                    </div>
                </button>
                
            </div>
            </div>
        </div>