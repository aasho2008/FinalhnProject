<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
    <head>
    <noscript><div class="alert alert-warning alert-dismissible fade show text-center" role="alert">
        <strong>Your browser does not support JavaScript!</strong> <noscript> <div class="error"> We're sorry but our site <strong>requires</strong> JavaScript. </div> </noscript></div></noscript>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=0">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

     <title> @yield('title')</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
       
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
    @yield('addtional_css')
    
 
</head>
<body>
   
    @include('includes.header_guset')

    @yield('content')
   
    @include('includes.footer_guset')

<!--    <script src="{{ asset('js/app.js') }}"></script>-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        
        function openNav() {
    document.getElementById("mySidenav").style.width = "300px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0px";
}

function openCartNav() {
    document.getElementById("myCartSideNav").style.width = "300px";
}

function closeCartNav() {
    document.getElementById("myCartSideNav").style.width = "0px";
}
    </script>
    <script>
        $(document).ready(function() {
 
  $('#signup_form').submit(function(e) {
    e.preventDefault();
    var f_name = $('#f_name').val();
    var l_name = $('#l_name').val();
    var email = $('#email').val();
    var password = $('#password').val();
 
    $(".error").remove();
 
    if (f_name.length < 1) {
      $('#f_name').after('<span class="error">This field is required</span>');
    }
    if (l_name.length < 1) {
      $('#l_name').after('<span class="error">This field is required</span>');
    }
    if (email.length < 1) {
      $('#email').after('<span class="error">This field is required</span>');
    } else {
      var regEx = /^[A-Z0-9][A-Z0-9._%+-]{0,63}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/;
      var validEmail = regEx.test(email);
      if (!validEmail) {
        $('#email').after('<span class="error">Enter a valid email</span>');
      }
    }
    if (password.length < 8) {
      $('#password').after('<span class="error">Password must be at least 8 characters long</span>');
    }
  });
 
});
</script>
    @yield('jscript')
</body>
</html>
