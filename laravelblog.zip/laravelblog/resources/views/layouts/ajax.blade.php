<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">

    <head>
    <noscript>Your browser does not support JavaScript!</noscript>
    <noscript> <div class="error message"> We're sorry but our site <strong>requires</strong> JavaScript. </div> </noscript>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="ROBOTS" content="NOINDEX, NOFOLLOW">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title')</title>
    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="{{ asset('css/bootstrap-datepicker3.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/bl_custom.css') }}" rel="stylesheet">
    <link href="{{ asset('css/bl_media.css') }}" rel="stylesheet">
    <link href="{{ asset('css/jquery.growl.css') }}" rel="stylesheet">
    <link href="{{ asset('css/jquery-ui.css') }}" rel="stylesheet">
    <link href="{{ asset('css/jquery-confirm.css') }}" rel="stylesheet">
    @yield('addtional_css')
    <script> var AJAX_LOADER_URL = '';</script>
    <style>
     .blockUI.blockOverlay{z-index: 9999; border: medium none; margin: 0px; padding: 0px; width: 100%; height: 100%; top: 0px; left: 0px; background-color: rgb(0, 0, 0); opacity: 0.6; cursor: wait; position: fixed;}    
     .blockUI.blockMsg{z-index: 9999; position: fixed; padding: 5px; margin: 0px 0px 0px -50px; width: auto; top: 40%; left: 50%; text-align: center; color: rgb(0, 115, 187); border: medium none; background-color: rgb(255, 255, 255); cursor: wait; border-radius: 5px;}    
    </style>
</head>
<div class="blockUI blockOverlay overlay"></div>
<div class="blockUI blockMsg blockPage overlay">Please Wait...</div>
<body>
    <!--header html end here-->
    <div id="wrapper" class="popUp">
        <div id="iframeMessage"></div>
        @if (Session::has('message'))

        <div class="alertMsgBox">
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                {{ Session::get('message') }}
            </div>
        </div>
        @endif

        @if (count($errors) > 0)
        <div class="alertMsgBox">
            <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        </div>
        @endif
        @yield('content')
    </div>



    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    <script src="https://code.jquery.com/jquery-migrate-3.0.0.min.js"></script>
    <script src="{{ asset('js/bootstrap-datepicker.min.js') }}"></script>

    <script type="text/javascript" src="{{ asset('/js/jquery.growl.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/jquery.confirm.new.js') }}"></script>
    {{-- Assign- This is required to support object.assign in IE--}}

    <script src="{{ asset('js/jquery.blockUI.js') }}"></script>
    <script src="{{ asset('js/custom.js') }}"></script>
    <script src="{{ asset('js/common.js') }}"></script>
    <script src="{{ asset('js/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('js/misc.js') }}"></script>
    <script src="{{ asset('js/validation/validate_functions.js') }}"></script>
    <script>
        var default_messages = {
            csrf_token: "{{ csrf_token() }}",
            phone_number_validate: "{{trans('application/form/caf_info.phone_number_validate')}}",
            ajax_image: "{{ asset('/images/ajax-loader.gif') }}",
        }
    </script>
    @yield('jscript')
    <script>
        jQuery(document).ajaxError(function (event, xhr, request, settings) {
            if (xhr.status === 401) {
                window.top.location.reload();
            }
        });
    </script>
</body>
</html>
