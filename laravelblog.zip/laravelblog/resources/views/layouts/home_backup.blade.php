<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
    <head>        
<noscript><div class="alert alert-warning alert-dismissible fade show text-center" role="alert">          
          <strong>Your browser does not support JavaScript!</strong> <noscript> <div class="error"> We're sorry but our site <strong>requires</strong> JavaScript. </div> </noscript></div></noscript>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>        
        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Styles -->
        <!-- Styles -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <link href="{{ asset('css/bl_custom.css') }}" rel="stylesheet">
        <link href="{{ asset('css/bl_media.css') }}" rel="stylesheet">
        <script> var AJAX_LOADER_URL = ''; </script>
    </head>
    <body>
                <!-- Header part start here -->
              @include('includes.home_header')
                <!-- Header part end here -->


            @yield('content')
            @include('includes.home_footer')
        </div>

        <!-- Scripts -->
        <script src="{{ asset('js/app.js') }}"></script>
    </body>
</html>
 