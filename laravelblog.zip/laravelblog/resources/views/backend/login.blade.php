@extends('backend_guest')
@section('content')
<style>
    
    label.error{ color:#ff0000; font-size:0.7857rem; text-align:left; line-height:21px; font-weight:300; margin:0;}

</style>
<div class="card card-login mx-auto mt-5">
    @if ($errors->has('email'))
    <div class='alert alert-danger errmsg' id='errmsg' > {{ $errors->first('email') }} <button type='button' class='close' data-dismiss='alert' aria-label='Close'> <span aria-hidden='true'>&times;</span> </button> </div>
    @endif
    @if ($errors->has('password'))
    <div class='alert alert-danger errmsg' id='errmsg' > {{ $errors->first('password') }} <button type='button' class='close' data-dismiss='alert' aria-label='Close'> <span aria-hidden='true'>&times;</span> </button> </div>
    @endif
    @if(Session::has('loginFailed') === true)
    <div class='alert alert-danger errmsg' id='errmsg' > {{ trans('auth.failed')}} <button type='button' class='close' data-dismiss='alert' aria-label='Close'> <span aria-hidden='true'>&times;</span> </button> </div>
    @endif
    @if (Session::has('message'))
    <div class="alert alert-success alert-dismissible" role="alert">
        {{ Session::get('message') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
    @endif
    <div class="card-header">Login</div>
    <div class="card-body">
        {!!
        Form::open(
        array (
        'name' => 'frmLogin',
        'id' => 'frmLogin',
        'url' => route('backend_login_open'),
        Form::pkey() => ['rtoken' => request()->get('rtoken')],
        'autocomplete' => 'off'
        )
        )
        !!}
         <div class="row">
                        <div class="col text-left">
                            <div class="form-group">
                                <label class="fieldLabel" for="email">{{ trans('backend_form.label.email') }}</label>
                                {!!
                                Form::text('email',
                                null,
                                array(
                                'class' => 'form-control message',
                                'id' => 'email',
                                'maxlength'=>'150'
                                )
                                )
                                !!}

                            </div>
                            <div class="form-group">
                                <label class="fieldLabel" for="password">{{ trans('backend_form.label.password') }}</label>
                                {!!
                                Form::password('password',
                                array(
                                'class'=>'form-control  readonly-wrapper',
                                'id'=>'password',
                                'maxlength'=>'32'
                                )
                                )
                                !!}
                                <span class="eyeIcon eyeclose"></span>
                            </div>

                        </div>
                    </div>
<!--        {{ $errors->has('captcha') ? 'Invalid Captcha' : '' }}
        @if(config('captcha.re_captcha_req')==true)
        <div class="form-group googleCaptchabox clearfix text-center">
            <div class="g-recaptcha" data-callback="recaptchaCallback" data-sitekey="{{ config('captcha.re_cap_site') }}"></div>
            <input type="hidden" class="hiddenRecaptcha required" name="hiddenRecaptcha" id="hiddenRecaptcha">
        </div>
        <div class="" id="captcha_container"></div>
        @endif-->
        <button class="btn btn-primary btn-block"  type="submit">Login</button>
        {!! Form::close() !!}
        <div class="text-center">

            <a class="d-block small" href="{{ route('backend_forgot_password') }}">Forgot Password?</a>
        </div>
    </div>
</div>


@endsection

@section('pageTitle')
{{ "LOGIN PAGE" }}
@endsection
@section('jscript')
<script src="{{ asset('js/jquery.validate.js') }}"></script>
<script src="{{ asset('js/backend_login.js') }}"></script>

<script src='https://www.google.com/recaptcha/api.js'></script>
<script>
var messages = {
    _token: "{{ csrf_token() }}",
    valid_email_req: "{{ trans('error_message.login.valid_email_req') }}",
    valid_email_format: "{{ trans('error_message.login.valid_email_format') }}",
    email_max_length: "{{ trans('error_message.login.email_max_length') }}",
    password_required: "{{ trans('error_message.login.password_required') }}",
    email_min_length: "{{ trans('error_message.email_min_length') }}",
};
</script>
@endsection
