@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">{{ trans('backend_form.add_blog') }}</li>
</ol>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">

            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        {!!
                        Form::
                        open(
                        array(
                        'name'=>'AddEditblog',
                        'id'=>'AddEditblog',
                        'class' => 'form-master',
                        'url' => route('save_blog'),
                        'files' => true,
                        form::pkey()=> [
                        'blog_id' =>isset($DataRow['blog_id']) ? $DataRow['blog_id'] : null
                        ]
                        )
                        )
                        !!}
                        <div class="form-group">
                            <label class="fieldLabel" for="city_name">{{ trans('backend_form.blog_title') }}</label>
                            {!! Form::text('blog_title',
                            isset($DataRow['blog_title'])? $DataRow['blog_title'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'blog_title',
                            'maxlength' =>'100',
                            'placeholder'=>'Enter Blog'
                            ))
                            !!}
                        </div>

                        <div class="form-group">
                            <label class="fieldLabel" for="is_active">{{ trans('backend_form.status') }}</label>
                            {!!
                            Form::select(
                            'is_active',
                            [''=>trans('backend_form.status'),1=>'Active',0=>'Inactive'],
                            isset($DataRow['is_active'])? $DataRow['is_active'] : '',
                            ['id'=>'is_active',
                            'class'=>'form-control'
                            ])
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="country_id"> {{ trans('backend_form.country') }}</label>
                            {!!
                            Form::select(
                            'country_id',
                            [''=>trans('backend_form.please_select_country')] + Helpers::getCountryLists()->toArray(),
                            isset($DataRow['country_id']) ? $DataRow['country_id'] : null,
                            ['id'=>'country_id',
                            'class'=>'form-control'
                            ])
                            !!}

                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="image_icoan"> {{ trans('backend_form.image_icoan') }}</label>
                              {!! Form::textarea('content', null, ['id' => 'content', 'class' => 'ckeditor']) !!}

                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="image_icoan"> {{ trans('backend_form.image_icoan') }}</label>
                                <input type="file" name="image_icoan" id="image_icoan" class="form-control-file" accept="image/*">

                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="banner_image"> {{ trans('backend_form.banner_image') }}</label>
                            <input type="file" name="banner_image"  id="banner_image" class="form-control-file" accept="image/*">

                        </div>
                      
                        @if(!isset($DataRow['blog_id']))
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.save') }}</button>
                        @else
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.update') }}</button>
                        @endif
                        {!! Form::close() !!}
                    </div>
                    <!-- /.col-lg-6 (nested) -->

                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>


@endsection


@section('pageTitle')
{{ "City" }}
@endsection 

@section('addtional_css')
<link href="{{ asset('vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">
@endsection

@section('jscript')
<script src="//cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script src="{{ asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>


<script>
    
var messages = {
    get_city_list_ajax: "{{ URL::route('get_city_list_ajax') }}",
    get_state_by_country: "{{ URL::route('get_state_by_country') }}",
    ajax_image: "{{ asset('/images/ajax-loader.gif') }}",
    data_not_found: "{{ trans('error_message.no_records_found') }}",
    token: "{{ csrf_token() }}",
    state_id: "{{ isset($DataRow['state_id'])? $DataRow['state_id'] : '' }}",

};

</script>
<script src="{{ asset('js/jquery.validate.js') }}"></script>
<script src="{{ asset('js/backend/master/master.js') }}"></script>

<script>
jQuery(document).ready(function ($) {
    $('#country_id').change(function () {
        var countryID = $(this).val();
        if (countryID) {
            $("#state_id").before("<span class='docLoader' style='position: absolute;'><img src=" + messages.ajax_image + "></span>");
            $.ajax({
                "url": messages.get_state_by_country, // json datasource
                type: 'post',
                data: {country_id: countryID, _token: messages.token},
                success: function (res) {
                    if (res) {
                        $("#state_id").empty();
                        $("#state_id").append('<option value="">Select City</option>');
                        $.each(res, function (key, value) {
                            var sel = '';
                            if(messages.state_id ==  value.state_id) {
                                sel = 'selected';
                            }
                            $("#state_id").append('<option value="' + value.state_id + '" '+ sel +'>' + value.state_name + '</option>');
                        });
                    } else {
                        $("#state_id").empty();
                    }
                },
                complete: function (data) {
                    // Hide image container
                    $(".docLoader").hide();
                    $("#state_id").prop('disabled', false);
                }
            });
        } else {
            $("#state_id").empty();
            $("#state_id").append('<option>Select City</option>');
        }
    });
   // $('#country_id').find('select').trigger('change');
     $('#country_id').prop("selected", true).trigger('change')
});
</script>
@endsection