@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">Queries/Queries List</li>
</ol>

<!-- Icon Cards-->
<div class="mb-3">
    
    
        <div class="greywrap">
            {!!
            Form::
            open(
            array(
            'name'=>'manageQueries',
            'id'=>'manageQueries',
            )
            )
            !!}
            <div class="appSearch manpad">
                <div class="row">
                    <div class="col">
                        <div class="form-group">

                            {!!
                            Form::text(
                            'by_name',
                            null,
                            [
                            'id'=>'by_name',
                            'class'=>'form-control',
                            'placeholder'=>'Searc by Name',
                            'maxlength'=>'50'
                            ]
                            )
                            !!}
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <input class="btn btn-primary" value="Search" id="btnlogin" type="submit">
                        </div>
                    </div>
                </div>
            </div>
            {!! Form::close() !!}
<!--            <a class="btn btn-primary" href="{{route('add_modules')}}">Add Module</a>-->
            
        </div>
        <div class="table-responsive">
            <table class="table table-bordered  paraText table-striped" id="QueryTable" width="100%" cellpadding="1" cellspacing="0">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        <th>Customer Name</th>
                        <th>Customer Mobile</th>
                        <th>Customer Email</th>
                        <th>Customer City</th>
                        <th>Company name</th>
                        <th>Sigment Type</th>
                        <th>Customer Query</th>
                        <th>Query status </th>
                        <th>Action</th>
                    </tr>
                </thead>

            </table>
        </div>
   

</div>


@endsection


@section('pageTitle')
{{ "Queries master" }}
@endsection 

@section('addtional_css')
<link href="{{ asset('vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">
@endsection

@section('jscript')
<script src="{{ asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>


<script>
var messages = {
    get_query_list_ajax: "{{ URL::route('get_query_list_ajax') }}",
    data_not_found: "{{ trans('error_message.no_records_found') }}",
    token: "{{ csrf_token() }}",

};

</script>
<script src="{{ asset('js/backend/master/manage_quries.js') }}"></script>
@endsection