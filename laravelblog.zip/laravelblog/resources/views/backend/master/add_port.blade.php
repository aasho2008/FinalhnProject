@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">Add Port</li>
</ol>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">

            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        {!!
                        Form::
                        open(
                        array(
                        'name'=>'AddEditPort',
                        'id'=>'AddEditPort',
                        'class' => 'form-master',
                        'url' => route('save_port'),
                        form::pkey()=> [
                        'port_id' =>isset($DataRow['port_id']) ? $DataRow['port_id'] : null
                        ]
                        )
                        )
                        !!}
                        <div class="form-group">
                            <label class="fieldLabel" for="port_name">{{ "Port" }}</label>
                            {!! Form::text('port_name',
                            isset($DataRow['port_name'])? $DataRow['port_name'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'port_name',
                            'maxlength' =>'100',
                            'placeholder'=>'Enter Port'
                            ))
                            !!}
                        </div>


                        <div class="form-group">
                            <label class="fieldLabel" for="port_type"> {{ "Port Type" }}</label>
                            {!!
                            Form::select(
                            'port_type',
                            [''=>'Select Port Type'] + config('ed_common.PORTTYPE'),
                            isset($DataRow['port_type']) ? $DataRow['port_type'] : null,
                            ['id'=>'port_type',
                            'class'=>'form-control'
                            ])
                            !!}

                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="country_id"> {{ trans('backend_form.country') }}</label>
                            {!!
                            Form::select(
                            'country_id',
                            [''=>trans('backend_form.please_select_country')] + Helpers::getCountryLists()->toArray(),
                            isset($DataRow['country_id']) ? $DataRow['country_id'] : null,
                            ['id'=>'country_id',
                            'class'=>'form-control'
                            ])
                            !!}

                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="state_id"> {{ trans('backend_form.state') }} </label>

                            {!!
                            Form::select(
                            'state_id',
                            [''=>trans('backend_form.please_select_state')],
                            null,
                            ['id'=>'state_id',
                            'class'=>'form-control',
                            'disabled'=>'disabled'
                            ])
                            !!}

                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="city_id"> {{ trans('backend_form.city') }} </label>

                            {!!
                            Form::select(
                            'city_id',
                            [''=>trans('backend_form.please_select_city')],
                            null,
                            ['id'=>'city_id',
                            'class'=>'form-control',
                            'disabled'=>'disabled'
                            ])
                            !!}

                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="is_active">{{ trans('backend_form.status') }}</label>
                            {!!
                            Form::select(
                            'port_status',
                            [''=>trans('backend_form.status'),1=>'Active',0=>'Inactive'],
                            isset($DataRow['port_status'])? $DataRow['port_status'] : '',
                            ['id'=>'is_active',
                            'class'=>'form-control'
                            ])
                            !!}
                        </div>
                        @if(!isset($DataRow['port_id']))
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.save') }}</button>
                        @else
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.update') }}</button>
                        @endif
                        {!! Form::close() !!}
                    </div>
                    <!-- /.col-lg-6 (nested) -->

                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>


@endsection


@section('pageTitle')
{{ "Port" }}
@endsection 

@section('addtional_css')
<link href="{{ asset('vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">
@endsection

@section('jscript')
<script src="{{ asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>


<script>
var messages = {
    get_city_list_ajax: "{{ URL::route('get_city_list_ajax') }}",
    get_state_by_country: "{{ URL::route('get_state_by_country') }}",
    get_city_by_state: "{{ URL::route('get_city_by_state') }}",
    ajax_image: "{{ asset('/images/ajax-loader.gif') }}",
    data_not_found: "{{ trans('error_message.no_records_found') }}",
    token: "{{ csrf_token() }}",
    state_id: "{{ isset($DataRow['state_id'])? $DataRow['state_id'] : '' }}",
    city_id: "{{ isset($DataRow['city_id'])? $DataRow['city_id'] : '' }}",

};

</script>
<script src="{{ asset('js/backend/master/manage_city.js') }}"></script>
<script src="{{ asset('js/jquery.validate.js') }}"></script>
<script src="{{ asset('js/backend/master/master.js') }}"></script>

<script>
jQuery(document).ready(function ($) {
    $('#country_id').change(function () {
        var countryID = $(this).val();
        if (countryID) {
            $("#state_id").before("<span class='docLoader' style='position: absolute;'><img src=" + messages.ajax_image + "></span>");
            $.ajax({
                "url": messages.get_state_by_country, // json datasource
                type: 'post',
                data: {country_id: countryID, _token: messages.token},
                success: function (res) {
                    if (res) {
                        $("#state_id").empty();
                        $("#state_id").append('<option value=""  selected="selected">Select City</option>');
                        $.each(res, function (key, value) {
                            var sel = '';
                            if (messages.state_id == value.state_id) {
                                sel = 'selected';
                            }
                            $("#state_id").append('<option value="' + value.state_id + '" ' + sel + '>' + value.state_name + '</option>');
                        });
                    } else {
                        $("#state_id").empty();
                    }
                },
                complete: function (data) {
                    // Hide image container
                    $(".docLoader").hide();
                    $("#state_id").prop('disabled', false);
                }
            });
        } else {
            $("#state_id").empty();
            $("#state_id").append('<option>Select State</option>');
        }
    });
    $('#state_id').change(function () {
        var state_id = $(this).val();
        if (state_id) {
            $("#city_id").before("<span class='docLoader' style='position: absolute;'><img src=" + messages.ajax_image + "></span>");
            $.ajax({
                "url": messages.get_city_by_state, // json datasource
                type: 'post',
                data: {state_id: state_id, _token: messages.token},
                success: function (res) {
                    if (res) {
                        $("#city_id").empty();
                        $("#city_id").append('<option value="" selected="selected">Select City</option>');
                        $.each(res, function (key, value) {
                            var sel = '';
                            if (messages.city_id == value.city_id) {
                                sel = 'selected';
                            }
                            $("#city_id").append('<option value="' + value.city_id + '" ' + sel + '>' + value.city_name + '</option>');
                        });
                    } else {
                        $("#city_id").empty();
                    }
                },
                complete: function (data) {
                    // Hide image container
                    $(".docLoader").hide();
                    $("#city_id").prop('disabled', false);
                }
            });
        } else {
            $("#city_id").empty();
            $("#city_id").append('<option>Select City</option>');
        }
    });
    //$('#country_id').find('select').trigger('change');
    $('#country_id').prop("selected", true).trigger('change');
    setTimeout(function () {
        $('#state_id').trigger('change');
    }, 1000);
});
</script>
@endsection