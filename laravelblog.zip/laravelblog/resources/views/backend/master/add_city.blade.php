@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">{{ trans('backend_form.add_city') }}</li>
</ol>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">

            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        {!!
                        Form::
                        open(
                        array(
                        'name'=>'AddEditCity',
                        'id'=>'AddEditCity',
                        'class' => 'form-master',
                        'url' => route('save_city'),
                        form::pkey()=> [
                        'city_id' =>isset($DataRow['city_id']) ? $DataRow['city_id'] : null
                        ]
                        )
                        )
                        !!}
                        <div class="form-group">
                            <label class="fieldLabel" for="city_name">{{ trans('backend_form.city') }}</label>
                            {!! Form::text('city_name',
                            isset($DataRow['city_name'])? $DataRow['city_name'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'city_name',
                            'maxlength' =>'100',
                            'placeholder'=>'Enter City'
                            ))
                            !!}
                        </div>

                        <div class="form-group">
                            <label class="fieldLabel" for="is_active">{{ trans('backend_form.status') }}</label>
                            {!!
                            Form::select(
                            'is_active',
                            [''=>trans('backend_form.status'),1=>'Active',0=>'Inactive'],
                            isset($DataRow['is_active'])? $DataRow['is_active'] : '',
                            ['id'=>'is_active',
                            'class'=>'form-control'
                            ])
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="country_id"> {{ trans('backend_form.country') }}</label>
                            @if(isset($DataRow['state_id']))
                              @var  $countryId = Helpers::getCountryBYStateId((int)$DataRow['state_id'])
                            @endif
                            {!!
                            Form::select(
                            'country_id',
                            [''=>trans('backend_form.please_select_country')] + Helpers::getCountryLists()->toArray(),
                            isset($countryId->country_id) ? $countryId->country_id : null,
                            ['id'=>'country_id',
                            'class'=>'form-control'
                            ])
                            !!}

                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="state_id"> {{ trans('backend_form.state') }} </label>

                            {!!
                            Form::select(
                            'state_id',
                            [''=>trans('backend_form.please_select_state')],
                            null,
                            ['id'=>'state_id',
                            'class'=>'form-control',
                            'disabled'=>'disabled'
                            ])
                            !!}

                        </div>
                        @if(!isset($DataRow['city_id']))
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.save') }}</button>
                        @else
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.update') }}</button>
                        @endif
                        {!! Form::close() !!}
                    </div>
                    <!-- /.col-lg-6 (nested) -->

                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>


@endsection


@section('pageTitle')
{{ "City" }}
@endsection 

@section('addtional_css')
<link href="{{ asset('vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">
@endsection

@section('jscript')
<script src="{{ asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>


<script>
var messages = {
    get_city_list_ajax: "{{ URL::route('get_city_list_ajax') }}",
    get_state_by_country: "{{ URL::route('get_state_by_country') }}",
    ajax_image: "{{ asset('/images/ajax-loader.gif') }}",
    data_not_found: "{{ trans('error_message.no_records_found') }}",
    token: "{{ csrf_token() }}",
    state_id: "{{ isset($DataRow['state_id'])? $DataRow['state_id'] : '' }}",

};

</script>
<script src="{{ asset('js/backend/master/manage_city.js') }}"></script>
<script src="{{ asset('js/jquery.validate.js') }}"></script>
<script src="{{ asset('js/backend/master/master.js') }}"></script>

<script>
jQuery(document).ready(function ($) {
    $('#country_id').change(function () {
        var countryID = $(this).val();
        if (countryID) {
            $("#state_id").before("<span class='docLoader' style='position: absolute;'><img src=" + messages.ajax_image + "></span>");
            $.ajax({
                "url": messages.get_state_by_country, // json datasource
                type: 'post',
                data: {country_id: countryID, _token: messages.token},
                success: function (res) {
                    if (res) {
                        $("#state_id").empty();
                        $("#state_id").append('<option value="">Select City</option>');
                        $.each(res, function (key, value) {
                            var sel = '';
                            if(messages.state_id ==  value.state_id) {
                                sel = 'selected';
                            }
                            $("#state_id").append('<option value="' + value.state_id + '" '+ sel +'>' + value.state_name + '</option>');
                        });
                    } else {
                        $("#state_id").empty();
                    }
                },
                complete: function (data) {
                    // Hide image container
                    $(".docLoader").hide();
                    $("#state_id").prop('disabled', false);
                }
            });
        } else {
            $("#state_id").empty();
            $("#state_id").append('<option>Select City</option>');
        }
    });
   // $('#country_id').find('select').trigger('change');
     $('#country_id').prop("selected", true).trigger('change')
});
</script>
@endsection