@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">{{ "Add Module" }}</li>
</ol>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">

            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        {!!
                        Form::
                        open(
                        array(
                        'name'=>'AddEditModule',
                        'id'=>'AddEditModule',
                        'class' => 'form-master',
                        'url' => route('save_modules'),
                        form::pkey()=> [
                        'city_id' =>isset($DataRow['module_id']) ? $DataRow['module_id'] : null
                        ]
                        )
                        )
                        !!}
                        <div class="form-group">
                            <label class="fieldLabel" for="city_name">{{ "Module" }}</label>
                            {!! Form::text('module_name',
                            isset($DataRow['module_name'])? $DataRow['module_name'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'module_name',
                            'maxlength' =>'100',
                            'placeholder'=>'Enter Module'
                            ))
                            !!}
                        </div>

                        <div class="form-group">
                            <label class="fieldLabel" for="is_active">{{ trans('backend_form.status') }}</label>
                            {!!
                            Form::select(
                            'module_status',
                            [''=>trans('backend_form.status'),1=>'Active',0=>'Inactive'],
                            isset($DataRow['module_status'])? $DataRow['module_status'] : '',
                            ['id'=>'module_status',
                            'class'=>'form-control'
                            ])
                            !!}
                        </div>
                        @if(!isset($DataRow['module_id']))
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.save') }}</button>
                        @else
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.update') }}</button>
                        @endif
                        {!! Form::close() !!}
                    </div>
                    <!-- /.col-lg-6 (nested) -->

                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>


@endsection


@section('pageTitle')
{{ "Module" }}
@endsection 

@section('addtional_css')
<link href="{{ asset('vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">
@endsection

@section('jscript')
<script src="{{ asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>


<script>
var messages = {
   // get_city_list_ajax: "{{ URL::route('get_city_list_ajax') }}",
   // get_state_by_country: "{{ URL::route('get_state_by_country') }}",
    //ajax_image: "{{ asset('/images/ajax-loader.gif') }}",
    //data_not_found: "{{ trans('error_message.no_records_found') }}",
    token: "{{ csrf_token() }}",
    //state_id: "{{ isset($DataRow['module_id'])? $DataRow['module_id'] : '' }}",

};

</script>
<script src="{{ asset('js/jquery.validate.js') }}"></script>
<script src="{{ asset('js/backend/master/master.js') }}"></script>
@endsection