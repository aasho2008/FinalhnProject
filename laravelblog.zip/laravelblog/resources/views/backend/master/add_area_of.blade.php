@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">Add area of interest</li>
</ol>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">

            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        {!!
                        Form::
                        open(
                        array(
                        'name'=>'AddEditarea',
                        'id'=>'AddEditarea',
                        'class' => 'form-master',
                        'url' => route('save_area_of_interest'),
                        form::pkey()=> [
                        'area_id' =>isset($DataRow['area_id']) ? $DataRow['area_id'] : null
                        ]
                        )
                        )
                        !!}
                        <div class="form-group">
                            <label class="fieldLabel" for="are_of_name">Course</label>
                            {!! Form::text('are_of_name',
                            isset($DataRow['are_of_name'])? $DataRow['are_of_name'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'course_name',
                            'maxlength' =>'100',
                            'placeholder'=>'Enter area of interest'
                            ))
                            !!}
                        </div>
                         <div class="form-group">
                            <label class="fieldLabel" for="is_active">{{ trans('backend_form.status') }}</label>
                            {!!
                            Form::select(
                            'is_active',
                            [''=>trans('backend_form.status'),1=>'Active',0=>'Inactive'],
                            isset($DataRow['is_active'])? $DataRow['is_active'] : '',
                            ['id'=>'is_active',
                            'class'=>'form-control'
                            ])
                            !!}
                        </div>

                     
                        @if(!isset($DataRow['course_id']))
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.save') }}</button>
                        @else
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.update') }}</button>
                        @endif
                        {!! Form::close() !!}
                    </div>
                    <!-- /.col-lg-6 (nested) -->

                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>


@endsection


@section('pageTitle')
{{ "Area of interest master" }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')

<script>


</script>
<script src="{{ asset('js/jquery.validate.js') }}"></script>
<script src="{{ asset('js/backend/master/master.js') }}"></script>


@endsection