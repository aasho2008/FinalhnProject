@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">{{ "Add Role" }}</li>
</ol>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">

            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        {!!
                        Form::
                        open(
                        array(
                        'name'=>'AddEditRole',
                        'id'=>'AddEditRole',
                        'class' => 'form-master',
                        'url' => route('save_role'),
                        form::pkey()=> [
                        'user_role_id' =>isset($DataRow['user_role_id']) ? $DataRow['user_role_id'] : null
                        ]
                        )
                        )
                        !!}
                        <div class="form-group">
                            <label class="fieldLabel" for="city_name">{{ "Roless" }}</label>
                            {!! Form::text('user_role_name',
                            isset($DataRow['user_role_name'])? $DataRow['user_role_name'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'country_name',
                            'maxlength' =>'100',
                            'placeholder'=>'Enter Role'
                            ))
                            !!}
                        </div>
                         <div class="form-group">
                            <label class="fieldLabel" for="is_active">{{ trans('backend_form.status') }}</label>
                            {!!
                            Form::select(
                            'user_role_status',
                            [''=>trans('backend_form.status'),1=>'Active',0=>'Inactive'],
                            isset($DataRow['user_role_status'])? $DataRow['user_role_status'] : '',
                            ['id'=>'user_role_status',
                            'class'=>'form-control'
                            ])
                            !!}
                        </div>

                     
                        @if(!isset($DataRow['user_role_id']))
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.save') }}</button>
                        @else
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.update') }}</button>
                        @endif
                        {!! Form::close() !!}
                    </div>
                    <!-- /.col-lg-6 (nested) -->

                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>


@endsection


@section('pageTitle')
{{ "Role master" }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')

<script>


</script>
<script src="{{ asset('js/jquery.validate.js') }}"></script>
<script src="{{ asset('js/backend/master/master.js') }}"></script>
@endsection