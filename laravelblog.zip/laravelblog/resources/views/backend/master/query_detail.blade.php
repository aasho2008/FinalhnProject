@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">Queries Detail</li>
</ol>

<!-- Icon Cards-->
<div class="mb-3">


    <a href="{{ route('queries_list')}}" class="btn btn-primary">Back</a>
    <div class="table">
        <table class="table" width="100%" cellpadding="1" cellspacing="0">
            <thead>
                <tr>
                    <th>Customer Name:</th>
                    <td>{{ ucfirst($dataRow['name']) }}</td>
                </tr>
                <tr>
                    <th>Customer Mobile:</th>
                    <td>{{ $dataRow['mobile_no'] }}</td>
                </tr>
                <tr>
                    <th>Customer Email:</th>
                    <td>{{ $dataRow['email'] }}</td>
                </tr>
                <tr>
                    <th>Customer City:</th>
                    <td>{{ $dataRow['city_name'] }}</td>
                </tr>
                <tr>
                    <th>Company name:</th>
                    <td>{{ $dataRow['company_name'] }}</td>
                </tr>
                
                
                <tr>
                    <th>Query:</th>
                    <td>{{ $dataRow['query'] }}</td>
                </tr>
                <tr>
                    <th>Query Type:</th>
                    <td>{{ ucfirst($dataRow['query_type']) }}</td>
                </tr>
                <tr>
                    <th>Sigment Type:</th>
                    <td>{{ ucfirst($dataRow['sigment_type']) }}</td>
                </tr>
                <tr>
                    <th>Query status:</th>
                    <td>{{ $dataRow['query_status'] ==1 ? 'Complete' : 'Pending' }}</td>
                </tr>
                <tr>
                    <th>Medium:</th>
                    <td>{{  config('ed_common.MEDIUM.'.$dataRow['medium']) }}</td>
                </tr>

            </thead>

        </table>
    </div>


</div>


@endsection


@section('pageTitle')
{{ "Queries master" }}
@endsection 

@section('addtional_css')
<link href="{{ asset('vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">
@endsection

@section('jscript')
<script src="{{ asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>
@endsection