@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">Role/Role List</li>
</ol>

<!-- Icon Cards-->
<div class="mb-3">
    
    
        <div class="greywrap">
            {!!
            Form::
            open(
            array(
            'name'=>'manageRole',
            'id'=>'manageRole',
            )
            )
            !!}
            <div class="appSearch manpad">
                <div class="row">
                    <div class="col">
                        <div class="form-group">

                            {!!
                            Form::text(
                            'by_name',
                            null,
                            [
                            'id'=>'by_name',
                            'class'=>'form-control',
                            'placeholder'=>'Searc by Name',
                            'maxlength'=>'50'
                            ]
                            )
                            !!}
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <input class="btn btn-primary" value="Search" id="btnlogin" type="submit">
                        </div>
                    </div>
                </div>
            </div>
            {!! Form::close() !!}
            <a class="btn btn-primary" href="{{route('add_role')}}">Add Role</a>
            
        </div>
        <div class="table-responsive">
            <table class="table table-bordered  paraText table-striped" id="RoleTable" width="100%" cellpadding="1" cellspacing="0">
                <thead>
                    <tr>
                        <th>Role Name</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

            </table>
        </div>
   

</div>


@endsection


@section('pageTitle')
{{ "Role master" }}
@endsection 

@section('addtional_css')
<link href="{{ asset('vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">
@endsection

@section('jscript')
<script src="{{ asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>


<script>
var messages = {
    get_role_list_ajax: "{{ URL::route('get_role_list_ajax') }}",
    role_change_status: "{{ URL::route('role_change_status') }}",
    data_not_found: "{{ trans('error_message.no_records_found') }}",
    token: "{{ csrf_token() }}",

};

</script>
<script src="{{ asset('js/backend/master/manage_role.js') }}"></script>
<script src="{{ asset('js/bootbox.min.js') }}"></script>
<script>
jQuery(document).ready(function ($) {
    $("#RoleTable").on('click', '.changeRoleStaus', function (e) {
        var deleteid = $(this).attr('id')
        var splitid = deleteid.split("#");
        if (deleteid) {
            bootbox.confirm("Are you sure want to change status?", function (result) {
                if (result) {
                    // AJAX Request
                    $.ajax({
                        url: messages.role_change_status,
                        type: 'POST',
                        data: {id: splitid[0], status: splitid[1], _token: messages.token},
                        success: function (response) {
                            $('#RoleTable').dataTable()._fnAjaxUpdate();

                        }
                    });
                }

            });
        }
    });
});
</script>
@endsection