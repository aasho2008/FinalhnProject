@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">Ports</li>
</ol>

<!-- Icon Cards-->
<div class="mb-3">
   
  
        <div class="greywrap">
            {!!
            Form::
            open(
            array(
            'name'=>'managePort',
            'id'=>'managePort',
            )
            )
            !!}
            <div class="appSearch manpad">
                <div class="row">
                    <div class="col">
                        <div class="form-group">

                            {!!
                            Form::text(
                            'by_name',
                            null,
                            [
                            'id'=>'by_name',
                            'class'=>'form-control',
                            'placeholder'=>'Searc by Name',
                            'maxlength'=>'50'
                            ]
                            )
                            !!}
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <input class="btn btn-primary" value="Search" id="btnlogin" type="submit">
                        </div>
                    </div>
                </div>
            </div>
            {!! Form::close() !!}
            <a class="btn btn-primary" href="{{route('add_port')}}">Add Port</a>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered  paraText table-striped" id="PortTable" width="100%" cellpadding="1" cellspacing="0">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        <th>Port Name</th>
                        <th>Port Type</th>
                        <th>Country</th>
                        <th>state</th>
                        <th>City</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

            </table>
        </div>
    </div>



@endsection


@section('pageTitle')
{{ "Port" }}
@endsection 

@section('addtional_css')
<link href="{{ asset('vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">
@endsection

@section('jscript')
<script src="{{ asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>


<script>
var messages = {
    get_port_list_ajax: "{{ URL::route('get_port_list_ajax') }}",
    check_port_status: "{{ URL::route('check_port_status') }}",
    data_not_found: "{{ trans('error_message.no_records_found') }}",
    token: "{{ csrf_token() }}",

};

</script>
<script src="{{ asset('js/backend/master/manage_port.js') }}"></script>
<script src="{{ asset('js/bootbox.min.js') }}"></script>
<script>
jQuery(document).ready(function ($) {
    $("#PortTable").on('click', '.changePortStaus', function (e) {
        var deleteid = $(this).attr('id')
       var splitid = deleteid.split("#");

        if (deleteid) {
            // Confirm box
            bootbox.confirm("Are you sure want to change status?", function (result) {
                if (result) {
                    // AJAX Request
                    $.ajax({
                        url: messages.check_port_status,
                        type: 'POST',
                        data: {id: splitid[0],status:splitid[1],_token : messages.token},
                        success: function (response) {
                            $('#PortTable').dataTable()._fnAjaxUpdate();

                        }
                    });
                }

            });
        }
    });
});
</script>
@endsection