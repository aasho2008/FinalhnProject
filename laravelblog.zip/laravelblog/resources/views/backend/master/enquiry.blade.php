@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">Enquiry</li>
</ol>

<!-- Icon Cards-->
<div class="card mb-3">
    <div class="card-header">
        <i class="fas fa-table"></i>
        Enquiry List</div>
    <div class="card-body">
        <div class="greywrap">
            {!!
            Form::
            open(
            array(
            'name'=>'manageEnquiry',
            'id'=>'manageEnquiry',
            )
            )
            !!}
            <div class="appSearch manpad">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label class="sr-only" for="Lead_ID"></label>
                            {!!
                            Form::text(
                            'by_name',
                            null,
                            [
                            'id'=>'by_name',
                            'class'=>'form-control',
                            'placeholder'=>'Searc by Name',
                            'maxlength'=>'50'
                            ]
                            )
                            !!}
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <input class="btn btn-primary" value="Search" id="btnlogin" type="submit">
                        </div>
                    </div>
                </div>
            </div>
            {!! Form::close() !!}

        </div>
        <div class="table-responsive">
            <table class="table table-bordered  paraText table-striped" id="enquiryTable" width="100%" cellpadding="1" cellspacing="0">
                <thead>
                    <tr>
                        <th>Enquiry Name</th>
                        <th>Mobile NO.</th>
                        <th>Email</th>
                        <th>Nearest Branch</th>
                        <th>Type</th>

                    </tr>
                </thead>

            </table>
        </div>
    </div>

</div>


@endsection


@section('pageTitle')
{{ trans('backend_form.enquiry_master') }}
@endsection 

@section('addtional_css')
<link href="{{ asset('vendor/datatables/dataTables.bootstrap4.css')}}" rel="stylesheet">
@endsection

@section('jscript')
<script src="{{ asset('vendor/datatables/jquery.dataTables.js')}}"></script>
<script src="{{ asset('vendor/datatables/dataTables.bootstrap4.js')}}"></script>


<script>
var messages = {
    get_enquiry_list_ajax: "{{ URL::route('get_enquiry_list_ajax') }}",
    data_not_found: "{{ trans('error_message.no_records_found') }}",
    token: "{{ csrf_token() }}",

};

</script>
<script src="{{ asset('js/backend/master/manage_enquiry.js') }}"></script>
@endsection