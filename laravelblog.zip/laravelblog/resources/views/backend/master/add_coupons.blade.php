@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">{{ trans('backend_form.add_coupon') }}</li>
</ol>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">

            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        {!!
                        Form::
                        open(
                        array(
                        'name'=>'AddEditCoupon',
                        'id'=>'AddEditCoupon',
                        'class' => 'form-master',
                        'url' => route('save_coupon'),
                        form::pkey()=> [
                        'branch_id' =>isset($DataRow['coupon_id']) ? $DataRow['coupon_id'] : null
                        ]
                        )
                        )
                        !!}
                        <div class="form-group">
                            <label class="fieldLabel" for="coupon_code">{{ trans('backend_form.coupon_code') }}</label>
                            <span class="star">*</span>
                            {!! Form::text('coupon_code',
                            isset($DataRow['coupon_code'])? $DataRow['coupon_code'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'coupon_code',
                            'maxlength' =>'100',
                            'placeholder'=>'Enter Coupon Code'
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="valid_from">{{ trans('backend_form.city') }}</label>

                            <span class="star">*</span>
                            {!! Form::text('valid_from',
                            isset($DataRow['valid_from'])? $DataRow['valid_from'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'valid_from',
                            'maxlength' =>'100',
                            'placeholder'=>''
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="valid_to">{{ trans('backend_form.address') }}</label>
                            <span class="star">*</span>
                            {!! Form::text('valid_to',
                            isset($DataRow['valid_to'])? $DataRow['valid_to'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'valid_to',
                            'maxlength' =>'255',
                            'placeholder'=>''
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="coupon_value">{{ trans('backend_form.phone') }}</label>
                            <span class="star">*</span>
                            {!! Form::text('coupon_value',
                            isset($DataRow['coupon_value'])? $DataRow['coupon_value'] : '',
                            array(
                            'class'=>'form-control number',
                            'id'=>'coupon_value',
                            'maxlength' =>'10',
                            'placeholder'=>''
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="coupon_status">{{ trans('backend_form.resion') }}</label>
                            <span class="star">*</span>
                            {!! Form::text('coupon_status',
                            isset($DataRow['coupon_status'])? $DataRow['coupon_status'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'coupon_status',
                            'maxlength' =>'100',
                            'placeholder'=>''
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="is_active">{{ trans('backend_form.status') }}</label>
                            <span class="star">*</span>
                            {!!
                            Form::select(
                            'is_active',
                            [''=>trans('backend_form.status'),1=>'Active',0=>'Inactive'],
                            isset($DataRow['is_active'])? $DataRow['is_active'] : '',
                            ['id'=>'is_active',
                            'class'=>'form-control'
                            ])
                            !!}
                        </div>


                        @if(!isset($DataRow['country_id']))
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.save') }}</button>
                        @else
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.update') }}</button>
                        @endif
                        {!! Form::close() !!}
                    </div>
                    <!-- /.col-lg-6 (nested) -->

                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>


@endsection


@section('pageTitle')
{{ trans('backend_form.branch_page_title') }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')

<script>

    $(function () {
        $('.number').on('keydown', function (e) {
            -1 !== $.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) || (/65|67|86|88/.test(e.keyCode) && (e.ctrlKey === true || e.metaKey === true)) && (!0 === e.ctrlKey || !0 === e.metaKey) || 35 <= e.keyCode && 40 >= e.keyCode || (e.shiftKey || 48 > e.keyCode || 57 < e.keyCode) && (96 > e.keyCode || 105 < e.keyCode) && e.preventDefault()
        });
    })
</script>
<script src="{{ asset('js/jquery.validate.js') }}"></script>
<script src="{{ asset('js/backend/master/master.js') }}"></script>


@endsection