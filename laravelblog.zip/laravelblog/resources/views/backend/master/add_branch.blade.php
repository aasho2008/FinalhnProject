@extends('layout')

@section('content')

<!-- Breadcrumbs-->
<ol class="breadcrumb">

    <li class="breadcrumb-item active">{{ trans('backend_form.add_branch') }}</li>
</ol>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">

            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-6">
                        {!!
                        Form::
                        open(
                        array(
                        'name'=>'AddEditBranch',
                        'id'=>'AddEditBranch',
                        'class' => 'form-master',
                        'url' => route('save_branch'),
                        form::pkey()=> [
                        'branch_id' =>isset($DataRow['branch_id']) ? $DataRow['branch_id'] : null
                        ]
                        )
                        )
                        !!}
                        <div class="form-group">
                            <label class="fieldLabel" for="branch_name">{{ trans('backend_form.branch_name') }}</label>
                            <span class="star">*</span>
                            {!! Form::text('branch_name',
                            isset($DataRow['branch_name'])? $DataRow['branch_name'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'branch_name',
                            'maxlength' =>'100',
                            'placeholder'=>'Enter Branch'
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="branch_city_id">{{ trans('backend_form.city') }}</label>

                            <span class="star">*</span>
                            {!! Form::text('branch_city_id',
                            isset($DataRow['branch_city_id'])? $DataRow['branch_city_id'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'branch_city_id',
                            'maxlength' =>'100',
                            'placeholder'=>''
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="branch_address">{{ trans('backend_form.address') }}</label>
                            <span class="star">*</span>
                            {!! Form::text('branch_address',
                            isset($DataRow['branch_address'])? $DataRow['branch_address'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'branch_address',
                            'maxlength' =>'255',
                            'placeholder'=>''
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="branch_phone">{{ trans('backend_form.phone') }}</label>
                            <span class="star">*</span>
                            {!! Form::text('branch_phone',
                            isset($DataRow['branch_phone'])? $DataRow['branch_phone'] : '',
                            array(
                            'class'=>'form-control number',
                            'id'=>'branch_phone',
                            'maxlength' =>'10',
                            'placeholder'=>''
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="branch_resion">{{ trans('backend_form.resion') }}</label>
                            <span class="star">*</span>
                            {!! Form::text('branch_resion',
                            isset($DataRow['branch_resion'])? $DataRow['branch_resion'] : '',
                            array(
                            'class'=>'form-control',
                            'id'=>'branch_resion',
                            'maxlength' =>'100',
                            'placeholder'=>''
                            ))
                            !!}
                        </div>
                        <div class="form-group">
                            <label class="fieldLabel" for="is_active">{{ trans('backend_form.status') }}</label>
                            <span class="star">*</span>
                            {!!
                            Form::select(
                            'is_active',
                            [''=>trans('backend_form.status'),1=>'Active',0=>'Inactive'],
                            isset($DataRow['is_active'])? $DataRow['is_active'] : '',
                            ['id'=>'is_active',
                            'class'=>'form-control'
                            ])
                            !!}
                        </div>


                        @if(!isset($DataRow['country_id']))
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.save') }}</button>
                        @else
                        <button type="submit" class="btn btn-primary">{{ trans('backend_form.update') }}</button>
                        @endif
                        {!! Form::close() !!}
                    </div>
                    <!-- /.col-lg-6 (nested) -->

                    <!-- /.col-lg-6 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>


@endsection


@section('pageTitle')
{{ trans('backend_form.branch_page_title') }}
@endsection 

@section('addtional_css')
@endsection

@section('jscript')

<script>

    $(function () {
        $('.number').on('keydown', function (e) {
            -1 !== $.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) || (/65|67|86|88/.test(e.keyCode) && (e.ctrlKey === true || e.metaKey === true)) && (!0 === e.ctrlKey || !0 === e.metaKey) || 35 <= e.keyCode && 40 >= e.keyCode || (e.shiftKey || 48 > e.keyCode || 57 < e.keyCode) && (96 > e.keyCode || 105 < e.keyCode) && e.preventDefault()
        });
    })
</script>
<script src="{{ asset('js/jquery.validate.js') }}"></script>
<script src="{{ asset('js/backend/master/master.js') }}"></script>


@endsection