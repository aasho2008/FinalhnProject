<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/bootstrap.css.css">
</head>
<body style="margin:0px;">
<div id="mySidenav" class="sidenav">
		  <a href="javascript:void(0)" id="closebtn" onclick="closeNav()">&times;</a>
		  <hr>
		  <a href="layout.blade.php"><i class="fa fa-home" aria-hidden="true"></i>Home</a>
		  <a href="#"><i class="fa fa-question-circle"></i>Help</a>
		  <a href="signup.html"><i class="fa fa-user"></i>Signup/Signin</a>
		 <hr>
		  <a href="layout.blade.php">Home</a>
		  <a href="#">Help</a>
		  <a href="aboutus.html">About Us</a>
		  <a href="#career.html">Career</a>
		  <a href="#">Blog</a>
		  <a href="Accessbility.html">Accessbility</a>
		  <a href="#">Be a Hunger Night</a>
		 <button class="button-sidenav">Get Hunger Night Credits</button>
	</div>
					<div id="myCartSideNav" class="cartSideNav" style="border-left: 1px solid #CCCCCC;">
		  <a href="javascript:void(0)" id="closebtnCart" onclick="closeCartNav()" style="">&times;</a>
		  <hr>

	</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 header">
			
				
			
			<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 padding-left-0 padding-right-0 side-menu"  onclick="openNav()">&#9776; </div>
			<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 text-center logo-section ">
			 <a href="hungernight1.html"<img src="images/logo.jpg" style="height: 65%;"></a>
				<span id="hunger-text">HUNGER NIGHT</span>
			</div>
			<div class="header-right">
			<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 cart-root">
			
				<button class="cart-button">
					<div class="cart-icon"><i class="fa fa-shopping-cart"></i></div>
					<div class="cart-total">
						<span>0</span>
					</div>
				</button>
				
			</div>
			</div>
		</div>

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding">
				<img src="images/anim1.png" height="400px" width="100%">
					<div class="centered">Favourite Food Delivery in Noida</div>
					<div class="centered1">Get your favourite Noida restaurant delivery food at your door step</div>
					<div class="centered2">Deliverly Address</div>

					<div class="box">
					  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center input-container padding-14">
					      
					      <input class="input" type="search" id="search" placeholder="Enter Your delivery address ">
					      <button class="search-btn" type="">Find Restaurant</button>
					  </div>
				</div>			 
		</div>
		
		
	
		
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="location">
				<a href="#">HungerNight</a> >
				<a href="#">Food Delivery</a> >
				<a href="#">Noida</a>
			</div>
		</div>

		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		
			<div class="icon1">
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
				<a href="#"><i class="fas fa-beer zoom"></i></a>
			</div>
		</div>
		
		<!--<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 group2">
			<span>Display 20 of 150 deloivery option in Noida</span>
		</div>-->
		<div class="main">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin-zero dash"    style="margin-top: 30px;">
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				<span>
				Note for underground
				sector,Noida
				</span>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin-zero dash">
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				<span>
				Note for underground
				sector,Noida
				</span>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin-zero dash">
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				<span>
				Note for underground
				sector,Noida
				</span>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 margin-zero dash">
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				<span>
				Note for underground
				sector,Noida
				</span>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 ">
				<img src="images/anim1.png">
				Note for underground
				sector,Noida
				</div>
				<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1">
				</div>
		</div>
		<div class="center1">
			<ul class="pagination">
				<li><a href="#"><<</a></li>
				<li><a href="#">1</a></li>
				<li><a href="#">2</a></li>
				<li><a href="#">3</a></li>
				<li><a href="#">4</a></li>
				<li><a href="#">5</a></li>
				<li><a href="#">>></a></li>
			</ul>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
				</div>
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
			Hunger Night is food delivery anywhere you go. With one of the largest networks of restaurant delivery options in San Francisco, choose from 1519 restaurants near you delivered in under an hour! Enjoy the most delicious San Francisco restaurants from the comfort of your home or office. Browse by name, cuisine, or staff picks personalized to your location.
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
				</div>
			</div>

			
			
		</div>
		
		<footer class="container-fluid text-center footer-login ">
  <div class="row content">
	<div class="col-md-12" >
		<div class="col-md-12" >
			<div class="col-md-2 ">
				<ul>
					<li class="liHeading-login">Get to Know Us</li>
					<li><a href="#">About us</a></li>
					<li><a href="#">Careers</a></li>
					<li><a href="#">Blog</a></li>
					<li><a href="#">Accessibility</a></li>
					<li><a href="https://www.youtube.com/c/hungernight" onclick="window.open(this.href); return false;" onkeypress="window.open(this.href); return false;">Youtube</a></li>
					<li><a href="https://twitter.com/hunger_night" onclick="window.open(this.href); return false;" onkeypress="window.open(this.href); return false;">Twitter</a></li>
				</ul>
			</div>
			<div class="col-sm-2">
				<ul>
					<li class="liHeading-login">Let Us Help You</li>
					<li><a href="#">Account Details </a></li>
					<li><a href="#">Order History</a></li>
					<li><a href="#">Help us</a></li>
				</ul>
			</div>
			<div class="col-sm-4">
				<ul>
					<li class="liHeading-login">Doing Business</li>
					<li><a href="#">Become a nighter</a></li>
					<li><a href="#">Be a Partner Restaurant</a></li>
					<li><a href="#">Get Hunger nighters for  Deliveries</a></li>
				</ul>
			</div>
			<div class="col-sm-2 apps">
				<a href="#"><img src="images/app.png" class="mobile-apps" width="148px;"></a>
				
			</div>
			<div class="col-sm-2 apps">
				<a href="#"><img src="images/ggogle.png" class="mobile-apps"></a>
				
			</div>
			
			
			<div class="col-md-12 padding-0 padding-top-15" >
			
			
			
			<div class="col-md-12 link-footerlogin" >
			
				<div class="col-md-2">
					<a href="#">Terms of Service</a>
				</div>
				<div class="col-md-1">
					<a href="#">Privacy</a>
				</div>
				<div class="col-md-2">
					<a href="#">Delivery Locations</a>
				</div>
				<div class="col-md-2 copyright-login">
					© 2018 HungerNight
				</div>
				
				
				<div class="col-md-5 col-sm-12 col-sm-12 social "  >
					<div class="col-md-1 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-facebook"></i></a>
					</div>
					<div class="col-md-1 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-twitter"></i></a>
					</div>
					<div class="col-md-1 col-sm-12 col-xs-12">
						<a href="#"><i class="fa fa-instagram"></i></a>
					</div>
				</div>
				
			</div>
		</div>
		
	</div>
	
		
	</div>



</footer>		
</body>
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "300px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0px";
}
function openCartNav() {
    document.getElementById("myCartSideNav").style.width = "300px";
}

function closeCartNav() {
    document.getElementById("myCartSideNav").style.width = "0px";
}
</script>
</html>
