@extends('layouts.error')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="pageInvalid">
                <img src="images/notfound_icon.svg" height="146" width="164">
                <h1 class="mt20 midBlueText mt30">404 - Not Found</h1>
                <h2>Requested resource does not exist</h2>
            </div>
        </div>
      </div>
</div>
@endsection
@section('pageTitle')
404 - Not Found
@endsection
