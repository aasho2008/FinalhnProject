@extends('layouts.error')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="pageInvalid">
                <img src="/images/forbidden_icon.svg" width="461" height="110">
                <h1 class="midBlueText mt30">403 - Forbidden</h1>
                <h2>You are not authorized to view this screen.</h2>
            </div>
        </div>
      </div>
</div>
@endsection
@section('pageTitle')
403 - Forbidden
@endsection
