@extends('layouts.error')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="pageInvalid">
                <img src="/images/unexpected_icon.svg" width="123" height="141">
                <h1 class="mt30 midBlueText">An Unexpected<br>Error has Occurred</h1>
                <h2>We're on the case and things should be up and running shortly!</h2>
            </div>
        </div>
      </div>
</div>
@endsection
@section('pageTitle')
An Unexpected
@endsection
