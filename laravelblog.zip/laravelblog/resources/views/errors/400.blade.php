@extends('layouts.error')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="pageInvalid">
                <img src="/images/forbidden_icon.svg" width="461" height="110">
                <h1 class="mt20 midBlueText mt30">400 - Bad Request</h1>
                <h2>Network issue. Please try after sometime.</h2>
            </div>
        </div>
      </div>
</div>
@endsection
@section('pageTitle')
400 - Forbidden
@endsection
