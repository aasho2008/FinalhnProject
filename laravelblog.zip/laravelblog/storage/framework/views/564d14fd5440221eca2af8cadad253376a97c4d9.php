<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
    <noscript><div class="alert alert-warning alert-dismissible fade show text-center" role="alert">
        <strong>Your browser does not support JavaScript!</strong> <noscript> <div class="error"> We're sorry but our site <strong>requires</strong> JavaScript. </div> </noscript></div></noscript>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=0">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

     <title> <?php echo $__env->yieldContent('title'); ?></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
       
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">
    <?php echo $__env->yieldContent('addtional_css'); ?>
    
 
</head>
<body>
   
    <?php echo $__env->make('includes.header_guset', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>
   
    <?php echo $__env->make('includes.footer_guset', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--    <script src="<?php echo e(asset('js/app.js')); ?>"></script>-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript">
        
        function openNav() {
    document.getElementById("mySidenav").style.width = "300px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0px";
}

function openCartNav() {
    document.getElementById("myCartSideNav").style.width = "300px";
}

function closeCartNav() {
    document.getElementById("myCartSideNav").style.width = "0px";
}
    </script>>
    <?php echo $__env->yieldContent('jscript'); ?>
</body>
</html>
