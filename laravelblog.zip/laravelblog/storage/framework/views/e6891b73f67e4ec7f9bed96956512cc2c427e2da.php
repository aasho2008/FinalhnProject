<?php $__env->startSection('content'); ?>

		<div class="login-root">
			<div class="login-centered">
				<span class="opacityAndSize_parent text-center">
					<div>
					`	<h1 class="login-h1">Sign In</h1>
						<p class="login-p">New to HungerNight?
							<a href="signup.html"><button class="signup-link">Sign Up</button></a>
						</p>
						<center>
						<div class="width">
						<button class="signin-facebook">
							<span class="login-btnIconcontroller">
								<i class="fa fa-facebook"></i>
								Sign in with Facebook
							</span>
						</button>
						<button class="signin-google">
							<span class="login-btnIconcontroller">
								<i class="fa fa-google"></i>
								Sign in with Google
							</span>
						</button>
						<p class="login-orWithEmail">
						
						Or with email
						
						</p>
						<form id="login-form text-center">
							<label class="input-root">
								<div class="input-label">Email</div>
								<input type="email" class="input-input" tabindex="1" value name="Email">
							</label>
							<label class="input-root">
								<div class="input-label">Password</div>
								<div class="input-subLebel"><a href="#" class="button-root">Forgot Your Password?</a></div>
								<div class="input-password">
									<input type="password" class="input-input" tabindex="2" value name="Password">
									<div class="input-show" tabindex="-1">Show</div>
								</div>
							</label>
							<button class="login-submit" tabindex="3" type="submit">
								<span class="submit-text">Sign in</span>
							</button>
						</form>
						</div>
						</center>
					</div>
				</span>
				
			</div>
		</div>
		
<?php $__env->stopSection(); ?>


<?php $__env->startSection('pageTitle'); ?>
<?php echo e("login"); ?>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('addtional_css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jscript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>