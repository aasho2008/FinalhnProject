<div class="footer-background">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 new-font-15" style="border-bottom: 1px solid #ffffff;">
        <div class="col-lg-1 col-md-1 col-sm-0 col-xs-0"></div>
        <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
            <div class="col-lg-1 col-md-1 col-sm-0 col-xs-0"></div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 text-center ourfamily">Our Family</div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 text-center text-90"><img src="image/travelguru_logo.png"></div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 text-center text-90"><img src="image/adventure_nation logo.png"></div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 text-center text-90"><img src="image/yatralogo.png"></div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 text-center text-90"><img src="image/tsiyatra.png"></div>
            <div class="col-lg-1 col-md-1 col-sm-0 col-xs-0"></div>
        </div>
        <div class="col-lg-1 col-md-1 col-sm-0 col-xs-0"></div>
    </div>

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 back-blue">
        <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
        <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 back" >

            <ul class="nav nav-pills first" id="nav" >
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <li><a data-toggle="collapse" href="#menu1">Company Information<i class="fa fa-angle-down"></i></a></li>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 ">
                    <li><a href="#">Invester Relation</a></li>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <li><a data-toggle="collapse" href="#menu2">Partner with Logistic<i class="fa fa-angle-down"></i></a></li>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <li><a href="#">Yatra for Bussiness</a></li>
                </div>
            </ul>

            <div class="tab-content">
                <div id="menu1" class="collapse">
                    <h3>Company Information</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>

                <div id="menu2" class="collapse">
                    <h3>Partner with Logistic</h3>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                </div>
            </div>

            <ul class="nav nav-pills second" id="nav">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <li><a href="#">Yatra on Mobile</a></li>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <li><a data-toggle="collapse" href="#menu3">Customer Care<i class="fa fa-angle-down"></i></a></li>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <li><a data-toggle="collapse" href="#menu4">Product Offering<i class="fa fa-angle-down"></i></a></li>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <li><a data-toggle="collapse" href="#menu5">More<i class="fa fa-angle-down"></i></a></li>
                </div>
            </ul>

            <div class="tab-content">


                <div id="menu3" class="collapse">
                    <h3>Customer Care</h3>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                </div>

                <div id="menu4" class="collapse">
                    <h3>Product Offering</h3>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                </div>

                <div id="menu5" class="collapse">
                    <h3>More</h3>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                </div>

            </div>


        </div>
        <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
    </div>

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 img-red">
        <div class="col-lg-1 col-md-1 col-sm-0 col-xs-0"></div>
        <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">

            <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12  text-center"><img src="<?php echo e(asset('image/icon-pics/dss_logo.png')); ?>"></div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12  text-center"><img src="<?php echo e(asset('image/icon-pics/verisigned_logo.png')); ?>"></div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12  text-center"><img src="<?php echo e(asset('image/icon-pics/googleplaylogo.png')); ?>"></div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12  text-center"><img src="<?php echo e(asset('image/icon-pics/applestorelogo.png')); ?>"></div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 img-center text-center "><img src="<?php echo e(asset('image/icon-pics/visa.png')); ?>"></div>
            <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12  text-center"><img src="<?php echo e(asset('image/icon-pics/emilogo.png')); ?>"></div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 text-center"><img src="<?php echo e(asset('image/icon-pics/net_banking_logo.png')); ?>"></div>
        </div>
        <div class="col-lg-1 coal-md-1 col-sm-0 col-xs-0"></div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 new-font-15">
        <div class="col-lg-1 col-md-1 col-sm-0 col-xs-0"></div>
        <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 text-center font-15 ">
            <small>Copyrights © 2018 Directship Private Limited, India. All Right Reserved</small>
        </div>
        <div class="col-lg-1 col-md-1 col-sm-0 col-xs-0"></div>
    </div>
</div>