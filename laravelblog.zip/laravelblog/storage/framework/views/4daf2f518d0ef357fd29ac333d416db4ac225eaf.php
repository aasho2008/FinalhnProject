<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
<title><?php echo $__env->yieldContent('pageTitle'); ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="<?php echo e(asset('css/bl_custom.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bl_media.css')); ?>">
</head>
<body>
<header class="clearfix header inner">
  <div class="container-fluid ptb20">
    <div class="row">
      <div class="logo col-4"><img src="<?php echo e(asset('images/pb-logo.svg')); ?>" alt="<?php echo e(config('clientdetails.client_name')); ?>"></a></div>
    </div>
  </div>
</header>
<section class="clearfix pt27"><?php echo $__env->yieldContent('content'); ?></section>
<?php echo $__env->yieldContent('addtional_css'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/backend_bl-custom.js')); ?>"></script>
<?php echo $__env->yieldContent('jscript'); ?>
</body>
</html>