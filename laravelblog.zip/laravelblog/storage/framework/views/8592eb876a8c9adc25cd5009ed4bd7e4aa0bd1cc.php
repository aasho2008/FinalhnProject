<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
         <title><?php echo $__env->yieldContent('pageTitle'); ?></title>
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
         <?php echo $__env->yieldContent('addtional_css'); ?>      
    </head>
    <body>
        <div class="container">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 header">
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 logo-section">
                    <div class="col-lg-12 col-md-12 col-sm-11 col-xs-11 logo-text text-center">
                         
                        <a href="layout.blade.php"><img src="<?php echo e(asset('images/logo.jpg')); ?>"></a>
                        <span id="hunger-text">HUNGER NIGHT</span>
                       
                    </div>
                </div>          
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 signup-section text-right">
                    <a href="login.html" class="btn">Sign In</a>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 signup-section text-right">
                    <a href="signup.html"><button class="button">Sign Up</button></a>
                </div>      
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="box_delivery">
                            <div class="serachBarheadertext">
                                Delivering Good Day Time
                            </div> 
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 input-container padding-15">                        
                                <input class="input" type="search" id="search" placeholder="Enter Your delivery address">
                                <button class="search-btn" type="">Find Restaurant</button>
                            </div>

                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 playstorelogo">
                                <h3 class="app-heading">Get the app:</h3>                                
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 apps-social">
                                    <a class="get-apps" href="#"><i class="fa fa-apple" aria-hidden="true"></i></a>
                                    <a class="get-apps" href="#"><i class="fa fa-android" aria-hidden="true"></i></a>
                                </div>
                            </div>
                    </div>                   
                    <div id="myCarousel" class="col-lg-12 col-md-12 col-sm-12 col-xs-12 carousel slide" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                      <li data-target="#myCarousel" data-slide-to="1"></li>
                      <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">
                      <div class="item active">
                        <img src="<?php echo e(asset('images/bnr1.jpg')); ?>" alt="food" style="width:100%;">
                      </div>

                      <div class="item">
                        <img src="<?php echo e(asset('images/food_ordering_banner.jpg')); ?>" alt="food" style="width:100%;">
                      </div>

                      <div class="item">
                        <img src="<?php echo e(asset('images/bnr10.jpg')); ?>" alt="food" style="width:100%;">
                      </div>
                    </div>
                    </div>
                    <!-- start banner on minislider-->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 del-portion">  
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 del-width" >
                              <h1 class="del-door">Delivering Goods: Delivering At Your Doorstep</h1>
                            </div>
                         <a href="aboutus.html">
                            <div class="arrow-portion">
                               <svg class="" height="32" viewBox="0 0 311 66"><g fill="none" transform="translate(1.000000, 1.000000)" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline><g transform="translate(154.500000, 47.500000) scale(1, -1) translate(-154.500000, -47.500000) translate(0.000000, 31.000000)"><polyline points="0 32.0244293 308.409682 32.0244293 277.333428 0.948174748"></polyline></g></g>    
                               </svg>
                            </div>
                        </a>
                    </div>
                    <!-- End banner on minislider-->
                    <!--Session Start text and image-->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 animationBlock">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 mobile-portion textLeft">
                            <div class="centertextLeft"><b>Satisfy your cravings</b><br/>
                            <br/><p>Experience a world of food, with your favorite restaurants at your fingertips.</p></div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 mobile-portion imgRight" id="imgslide"></div>
                    </div>
                    <!--Session End text and image-->
                    <!--Session Start text and image-->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 animationBlock">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 mobile-portion imgLeft" id="imgslide1"></div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 mobile-portion textLeft">
                            <div class="centertextLeft"><b>Anywhere you are</b><br/>
                            <br/><p>A family picnic in the park. Your date night at home. That late-night study session. Spend more time doing the things that matter to you most — we’ll take care of the rest.</p></div></div>
                        </div>
                    </div>
                    <!--Session End text and image-->
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mobile-portion">
                        <h1>How it works</h1>
                        <div class="img"><img src="<?php echo e(asset('images/mobile.jpg')); ?>"></div>
                        <h1>FIND YOUR FAVOURITS</h1>
                        <p class="">Satisfy your cravings with a huge selection</p>
                        <p class="">of resturants.</p>              
                    </div>
                    <div class="order">
                        <h1 class="">Ready to order?</h1>
                        <div class="box">
                              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 input-container padding-15">
                                  <input class="input" type="search" id="search" placeholder="Enter Your delivery address ">
                                  <button class="search-btn" type="">Find Restaurant</button>
                              </div>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-15">
                            <h3 class="app-heading">Get the app:</h3>
                            
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 apps-social">
                            <a class="get-apps" href="#"><i class="fa fa-apple" aria-hidden="true"></i></a>
                            <a class="get-apps" href="#"><i class="fa fa-android" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="container-fluid text-center footer">
        <div class="row content">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 ">
                    <ul>
                        <li class="liHeading">North India</li>
                        <li><a href=" <?php echo e(URL::to('noida_city.blade.php')); ?>">Noida</a></li>
                        <li><a href="Gaziabad.html">Gaziabad</a></li>
                        <li><a href="Greater Noida.html">Greater Noida</a></li>
                        <li><a href="New Delhi.html">New Delhi</a></li>
                        <li><a href="South Delhi.html">South Delhi</a></li>
                        <li><a href="Gurugram.html">Gurugram</a></li>
                        
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                    <ul>
                        <li class="liHeading">North India</li>
                        <li><a href="Deoria.html">Deoria</a></li>
                        <li><a href="Lucknow.html">Lucknow</a></li>
                        <li><a href="Kanpur.html">Kanpur</a></li>
                        <li><a href="Meerut.html">Meerut</a></li>
                        <li><a href="Dehradun.html">Dehradun</a></li>
                        
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                    <ul>
                        <li class="liHeading">South India</li>
                        <li><a href="#">Banglore</a></li>
                        <li><a href="#">Hydrabad</a></li>
                        <li><a href="#">Tiruvanantpuram</a></li>
                        <li><a href="#">Pune</a></li>
                        <li><a href="#">Chennai</a></li>
                    </ul>
                </div>

                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                    <ul>
                        <li class="liHeading">East India</li>
                        
                        <li><a href="#">Ahemdabad</a></li>
                        <li><a href="#">Surat</a></li>
                        <li><a href="#">Barodra</a></li>
                        <li><a href="#">Kota</a></li>
                        <li><a href="#">Jaipur</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                    <ul>
                        <li class="liHeading">Other Cities in India</li>
                        
                        <!--li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li>
                        <li><a href="#">demo</a></li-->
                    </ul>
                </div>

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding-0 padding-top-15" >
                    <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                        <ul>
                            <li class="liHeading">GET TO KNOW</li>
                            <li><a href="#">About us</a></li>
                            <li><a href="#">Careers</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Accessibility</a></li>
                            <li><a href="https://www.youtube.com/c/hungernight" onclick="window.open(this.href); return false;" onkeypress="window.open(this.href); return false;">Youtube</a></li>
                            <li><a href="https://twitter.com/hunger_night" onclick="window.open(this.href); return false;" onkeypress="window.open(this.href); return false;">Twitter</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                        <ul>
                            <li class="liHeading">HUNGER NIGHT HELP YOU</li>
                            <li><a href="#">Help us</a></li>
                            <!-- <li><a href="#">demo</a></li>
                            <li><a href="#">demo</a></li>
                            <li><a href="#">demo</a></li>
                            <li><a href="#">demo</a></li>
                            <li><a href="#">demo</a></li> -->
                        </ul>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                        <ul>
                            <li class="liHeading">DOING BUSINESS</li>
                            <li><a href="#">Become a nighter</a></li>
                            <li><a href="#">Be a Partner Restaurant</a></li>
                            <li><a href="#">Get Hunger nighters for  Deliveries</a></li>
                            
                        </ul>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 apps">
                        <a href="#" ><img src="<?php echo e(asset('images/app.png')); ?>" class="mobile-apps" width="148px;"></a>
                        <a href="#"><img src="<?php echo e(asset('images/ggogle.png')); ?>" class="mobile-apps"></a>
                    </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 link" >
                            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                                <a href="#">Terms of Service</a>
                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                                <a href="#">Privacy</a>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                                <a href="#">Delivery Locations</a>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 copyright">
                                © 2018 HungerNight
                            </div>
                            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 social"  id="social-social">
                                <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                                    <a href="#"><i class="fa fa-facebook"></i></a>
                                </div>
                                <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                                    <a href="#"><i class="fa fa-twitter"></i></a>
                                </div>
                                <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
                                    <a href="#"><i class="fa fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                </div>  
            </div>
        </div>      
    </footer>
    </body>
</html>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.carouFredSel-6.1.0-packed.js')); ?>"></script>
        <script src="<?php echo e(asset('js/tms-0.4.1.js')); ?>"></script>
        <script type="text/javascript">
            $( document ).ready(function() {
                $(window).scroll(function() {
                    var x = $(this).scrollTop();
                    $('#imgslide').css('background-position', '100% ' + parseInt(-x / 1) + 'px' + ', 0% ' + parseInt(-x / 2) + 'px, center top');
                    $('#imgslide1').css('background-position', '100% ' + parseInt(-x / 1) + 'px' + ', 0% ' + parseInt(-x / 2) + 'px, center top');
                });
            });
        </script>   
<script>
$(window).load(function () {
    $('.slider')._TMS({
        show: 0,
        pauseOnHover: false,
        prevBu: '.prev',
        nextBu: '.next',
        playBu: false,
        duration: 800,
        preset: 'fade',
        pagination: true, //'.pagination',true,'<ul></ul>'
        pagNums: false,
        slideshow: 8000,
        numStatus: false,
        banners: false,
        waitBannerAnimation: false,
        progressBar: false
    })
});
$(window).load(function () {
    $('.carousel1').carouFredSel({
        auto: false,
        prev: '.prev',
        next: '.next',
        width: 960,
        items: {
            visible: {
                min: 1,
                max: 4
            },
            height: 'auto',
            width: 240,
        },
        responsive: false,
        scroll: 1,
        mousewheel: false,
        swipe: {
            onMouse: false,
            onTouch: false
        }
    });
});
</script>
        <?php echo $__env->yieldContent('jscript'); ?>
    </body>
</html>
